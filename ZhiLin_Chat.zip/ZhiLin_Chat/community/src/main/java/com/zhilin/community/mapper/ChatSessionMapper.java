package com.zhilin.community.mapper;

import com.zhilin.community.pojo.database.ChatSession;
import org.apache.ibatis.annotations.*;

import java.time.Instant;
import java.util.List;

@Mapper
public interface ChatSessionMapper {
    // 更新会话最后消息
    @Update("UPDATE chat_session SET " +
            "last_message = #{content}, " +
            "last_active_time = #{timestamp}, " +
            "unread_count = unread_count + #{delta} " +
            "WHERE id = #{sessionId}")
    void updateSession(@Param("sessionId") String sessionId,
                          @Param("content") String content,
                          @Param("timestamp") Instant timestamp,
                          @Param("delta") int delta);

    @Update("UPDATE chat_session SET " +
            "unread_count = unread_count + #{delta} " +
            "WHERE id = #{sessionId}")
    void updateSessionRead(@Param("sessionId") String sessionId, @Param("delta") int delta);

    // 获取用户会话列表
    @Select("SELECT cs.*, i.avatar_url AS contact_avatar_url, i.nickname AS contact_nickname " +
            "FROM chat_session cs " +
            "LEFT JOIN information i ON cs.contact_id = i.user_id " +
            "WHERE cs.user_id = #{userId} ORDER BY cs.last_active_time DESC")
    @Results({
            @Result(property = "sessionId", column = "session_id"),
            @Result(property = "userId", column = "user_id"),
            @Result(property = "contactId", column = "contact_id"),
            @Result(property = "contactAvatarUrl", column = "contact_avatar_url"), // 映射头像
            @Result(property = "contactNickname", column = "contact_nickname")     // 映射昵称
    })
    List<ChatSession> selectUserSessions(Long userId);


    @Insert("INSERT into chat_session(id,user_id,contact_id,last_message,unread_count,last_active_time)" +
            "values (#{id},#{userId},#{contactId},#{lastMessage},#{unreadCount},#{lastActiveTime})")
    boolean insertChatSession(ChatSession chatSession);

    @Select("SELECT * from chat_session where id=#{sessionId}")
    ChatSession selectChatSession(@Param("sessionId") String sessionId);

    //查询已有会话的好友列表
    @Select("SELECT contact_id FROM chat_session WHERE user_id = #{userId}")
    List<Long> selectContactIdsByUserId(@Param("userId") Long userId);
}
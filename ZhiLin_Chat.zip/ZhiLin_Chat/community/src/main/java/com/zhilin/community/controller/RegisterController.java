package com.zhilin.community.controller;

import com.aventrix.jnanoid.jnanoid.NanoIdUtils;
import com.zhilin.community.pojo.database.Information;
import com.zhilin.community.pojo.register.RegisterForm;
import com.zhilin.community.pojo.Result;
import com.zhilin.community.pojo.database.User;
import com.zhilin.community.service.RegistrationService;
import com.zhilin.community.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.Map;
import java.util.Random;

@Slf4j
@RestController
public class RegisterController {

    @Autowired
    RegistrationService registrationService;
    @Autowired
    UserService userService;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/user/register")
    public Result register(@RequestBody RegisterForm form) throws Exception {
        User registeredUser = registrationService.registerUser(form);
        return Result.success(registeredUser);
    }

//    @PostMapping("/user/register")
//    public Result register(@RequestBody RegisterForm form) {
////        User registerUser = form.RegisterFormToUser();
//        User registerUser = new User();
//        Information registerInfo = form.RegisterFormToInformation();
//        char[] digitsOnly = "0123456789".toCharArray();
//        // 生成10位纯数字ID
//        String numericId = NanoIdUtils.randomNanoId(new Random(), digitsOnly, 10);
//        //先进行用户表信息的插入
//        registerUser.setChatNumber(numericId);
//        registerUser.setPasswordHash(passwordEncoder.encode(form.getPassword()));
//        registerUser.setRegisterDate(Instant.now());
//        registerUser.setStatus("normal");
//        registerUser.setRole("user");
//        int registerID = userService.getLatestID() + 1;
//        registerUser.setUserId(registerID);
//        registerInfo.setNickname("User-" + numericId);
//        registerInfo.setUserId(registerUser);
//        registerInfo.setFollowing(0L);
//        registerInfo.setFollowers(0L);
//        registerInfo.setPoints(0L);
//        registerInfo.setLikes(0L);
//        registerInfo.setViews(0L);
//        userService.registerUserInfo(registerUser);
//        userService.registerRelateInfo(registerInfo);
//        log.info("用户注册成功,随机生成的社区账号ID为：{}", numericId);
//        return Result.success(registerUser);
//    }

    @PostMapping("/user/check-phone")
    public Result checkPhone(@RequestBody Map<String, String> request) {
        String phoneNumber = request.get("phoneNumber");
        boolean isExisted = userService.checkPhoneExists(phoneNumber);
        log.info("手机号核验操作,是否被注册：{}", isExisted ? "是" : "否");
        return isExisted ? Result.error("手机号已被注册") : Result.success("手机号可用");
    }

    @PostMapping("/user/check-email")
    public Result register(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        boolean isExisted = userService.checkEmail(email);
        log.info("邮箱核验操作,是否被注册：{}", isExisted ? "是" : "否");
        return isExisted ? Result.error("邮箱已被注册") : Result.success("邮箱可用");
    }
}

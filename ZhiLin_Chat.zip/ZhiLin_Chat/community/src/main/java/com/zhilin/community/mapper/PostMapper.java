package com.zhilin.community.mapper;

import com.zhilin.community.pojo.response.PostResponse;
import com.zhilin.community.pojo.database.Post;
import org.apache.ibatis.annotations.*;

import java.time.Instant;
import java.util.List;

@Mapper
public interface PostMapper {

    List<PostResponse> selectPostsList(String nickname, String content, Instant startTime, Instant endTime);

    List<PostResponse> selectFollowedPosts(Integer userId);

    List<PostResponse> selectHotPosts(Integer userId);

    PostResponse selectPostById(Integer postId);

    //    @Insert(" INSERT INTO posts(post_id,content,images,release_date,likes,comments,stars,user_id) " +
//            "VALUES(#{postId},#{content},#{images},#{releaseDate},#{likes},#{comments},#{stars},#{userId})")
    void insertPost(Post post);

    @Select("SELECT * FROM posts WHERE user_id IN" +
            "(SELECT followed_id FROM userfollows WHERE follower_id = #{userId})")
    Long countFollowedPosts(Integer userId);

    @Select("SELECT COUNT(*) FROM posts")
    Integer countPosts();

    @Update("UPDATE posts SET likes = GREATEST(0, likes + #{delta}) WHERE post_id = #{postId}")
    void updateLikeCount(Integer delta, Integer postId);

    List<PostResponse> selectPostsListByUserId(Integer userId);

    List<PostResponse> selectCollectionsPostList(Integer userId);
}

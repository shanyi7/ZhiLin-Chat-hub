package com.zhilin.community.controller;

import com.zhilin.community.pojo.Result;
import com.zhilin.community.service.PresenceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/presence")
public class PresenceController {

    @Autowired
    private PresenceService presenceService;

    // 更新单个用户在线状态（示例请求：PUT /api/presence/123?online=true）
    @PutMapping("/{userId}")
    public Result updatePresence(@PathVariable Long userId, @RequestParam boolean online) {
        presenceService.updatePresence(userId, online);

        return online ? Result.success("用户上线成功") : Result.success("用户离线成功");
    }

    // 批量获取用户在线状态（示例请求：GET /api/presence/bulk?userIds=1&userIds=2）
    @GetMapping("/bulk")
    public Result getBulkPresence(@RequestParam List<Long> userIds) {
        Map<Long, Boolean> presenceMap = presenceService.getBulkPresence(userIds);
        return Result.success(presenceMap);
    }

}
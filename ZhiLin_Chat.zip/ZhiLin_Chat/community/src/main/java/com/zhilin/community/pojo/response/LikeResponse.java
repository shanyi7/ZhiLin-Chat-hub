package com.zhilin.community.pojo.response;

import lombok.Data;

/*点赞操作响应*/
@Data
public class LikeResponse {
    private Boolean newStatus;
    private Integer likeCount;

    public LikeResponse(Boolean newStatus, Integer likeCount) {
        this.newStatus = newStatus;
        this.likeCount = likeCount;

    }
}

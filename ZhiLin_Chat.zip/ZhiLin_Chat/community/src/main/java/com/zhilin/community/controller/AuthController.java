package com.zhilin.community.controller;

import com.zhilin.community.exception.BusinessException;
import com.zhilin.community.pojo.*;
import com.zhilin.community.pojo.database.Information;
import com.zhilin.community.pojo.database.User;
import com.zhilin.community.pojo.reset.ChatNumberEmail;
import com.zhilin.community.pojo.reset.CodeRequest;
import com.zhilin.community.pojo.reset.VerifyRequest;
import com.zhilin.community.service.CaptchaService;
import com.zhilin.community.service.EmailService;
import com.zhilin.community.service.UserService;
import com.zhilin.community.utils.RedisUtils;
import jakarta.mail.MessagingException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.concurrent.TimeUnit;

@Slf4j
@RestController
public class AuthController {
    private static final String CAPTCHA_PREFIX = "captcha:";
    @Autowired
    private UserService userService;
    @Autowired
    private CaptchaService captchaService;
    @Autowired
    private EmailService emailService;
    @Autowired
    private RedisUtils redisUtils;

    @PostMapping("/verify-email-chatNumber")
    public Result verifyChatNumberEmail(@RequestBody ChatNumberEmail chatNumberEmail) {
        String chatNumber = chatNumberEmail.getChatNumber();
        String email = chatNumberEmail.getAccount();
        User user = userService.getUserByChatNumber(chatNumber);
//        System.out.println(user);
        if (user == null) {
            return Result.error("社区账号不存在");
        }

        Information information = userService.getInformationByUserId(user.getUserId());
//        System.out.println(information);
        if (!information.getEmail().equals(email)) {
            return Result.error("社区账号与邮箱未绑定！");
        }
        log.info("账号与邮箱均无误,chatNumber：{},email：{}", chatNumber, email);
        return Result.success("账号与邮箱均无误");
    }

    @GetMapping("/verify/bindable")
    public Result verifyBindable(@RequestParam String email) {
        boolean isBindable = userService.getChatNumberByEmail(email) == null;
        return isBindable ? Result.success("邮箱可用") : Result.error("该邮箱不可用，已经被其他社区账号绑定！");
    }

    @PostMapping("/send-code")
    public Result sendVerificationCode(@RequestBody CodeRequest request) throws MessagingException {
        // 限流检查（60秒内禁止重复发送）
        String limitKey = "limit:" + request.getAccount();
        if (redisUtils.hasKey(limitKey)) {
            throw new BusinessException("BUSY", "请求过于频繁，请稍后再试");
        }
        String title = request.getKind().equals("RESET_PASSWORD") ? "密码重置验证码" : "账号安全绑定验证码";
        // 生成验证码并存储
        String code = captchaService.generateCode();
        captchaService.storeCode(request.getAccount(), code);
        log.info("邮箱验证码发送,code:{} ", code);
        // 选择发送渠道
        switch (request.getType()) {
            case "email":
                emailService.sendCaptchaEmail(request.getAccount(), code, title);
                break;
            case "sms":
//                smsService.sendSms(request.getAccount(), code);
                break;
            default:
                throw new IllegalArgumentException("不支持的验证方式");
        }

        // 设置限流锁
        redisUtils.set(limitKey, "1", 60, TimeUnit.SECONDS);

        return Result.success("验证码已成功发送");
    }

    @PostMapping("/verify-code")
    public Result verifyCode(@RequestBody VerifyRequest request) {

        // 从Redis获取存储的验证码
        String storedCode = (String) redisUtils.get(CAPTCHA_PREFIX + request.getAccount());
        // 验证逻辑
        if (storedCode == null) {
//            throw new BusinessException("EXPIRED", "验证码已过期");
            return Result.error("验证码已过期");
        }
        if (!captchaService.verifyCode(request.getAccount(), request.getCode())) {
            return Result.error("验证码错误");
//            throw new BusinessException("INPUT Error", "验证码错误");
        }

        // 生成访问令牌（JWT示例）
//        String token = JwtUtils.generateToken(request.getAccount());

        // 清除验证码缓存
        redisUtils.delete(CAPTCHA_PREFIX + request.getAccount());

        return Result.success("验证码核验成功");
    }
}
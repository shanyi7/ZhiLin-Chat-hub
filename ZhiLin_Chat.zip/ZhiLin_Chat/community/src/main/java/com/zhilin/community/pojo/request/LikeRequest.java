package com.zhilin.community.pojo.request;

import lombok.Data;

/*点赞操作请求*/
@Data
public class LikeRequest {
    private Integer userId;
    private String targetType;  //点赞对象类型：帖子（post）、评论（comment）、回复（reply）
    private Integer targetId;   //目标Id
    private String action;      //操作类型：点赞/取消点赞
}

package com.zhilin.community.pojo.page;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PageParam {
    // 默认分页参数
    private static final Integer DEFAULT_PAGE_NUM = 1;
    private static final Integer DEFAULT_PAGE_SIZE = 20;
    private static final Integer MAX_PAGE_SIZE = 100;

    // 当前页码（从1开始）
    private Integer pageNum;

    // 每页记录数
    private Integer pageSize;

    // 参数校验与默认值设置
    public void validate() {
        this.pageNum = (pageNum == null || pageNum < 1) ? DEFAULT_PAGE_NUM : pageNum;
        this.pageSize = (pageSize == null || pageSize < 1) ? DEFAULT_PAGE_SIZE :
                (pageSize > MAX_PAGE_SIZE) ? MAX_PAGE_SIZE : pageSize;
    }

    // 计算偏移量（用于SQL的LIMIT）
    @JsonIgnore
    public int getOffset() {
        return (pageNum - 1) * pageSize;
    }
}
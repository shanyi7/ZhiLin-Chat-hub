package com.zhilin.community.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

@Service
public class EmailService {
    @Autowired
    private JavaMailSender mailSender;
    @Autowired
    private TemplateEngine templateEngine;

    public void sendCaptchaEmail(String toEmail, String code, String title) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        // 设置模板变量
        Context context = new Context();
        context.setVariable("code", code);
        String htmlContent = templateEngine.process("email/verification", context);

        // 添加内嵌资源
        ClassPathResource logo = new ClassPathResource("static/logo.jpg");
        helper.addInline("logo", logo);

        helper.setFrom("zhilinhub@qq.com");
        helper.setTo(toEmail);
        helper.setSubject(title);
        helper.setText(htmlContent, true);

        mailSender.send(message);
    }
}
package com.zhilin.community.pojo.request;

import lombok.Data;

/*收藏操作请求*/
@Data
public class StarRequest {
    private Integer userId;
    private Integer postId;
    private String action;
}

package com.zhilin.community.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Encoders;
import io.jsonwebtoken.security.Keys;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.Map;

public class JwtUtils {
    // 生成符合 HS256 要求的密钥
    private static final SecretKey key = Keys.secretKeyFor(SignatureAlgorithm.HS256);
    private static final String base64Key = Encoders.BASE64.encode(key.getEncoded()); // 转换为 Base64 字符串
    //  private static final String signKey = "newStart";//签名密钥
    private static final Long expire = 43200000L; //有效时间

    /**
     * 生成JWT令牌
     *
     * @param claims JWT第二部分负载 payload 中存储的内容
     */
    public static String generateJwt(Map<String, Object> claims) {
        return Jwts.builder().addClaims(claims)//自定义信息（有效载荷）
                .signWith(SignatureAlgorithm.HS256, base64Key)//签名算法（头部）
                .setExpiration(new Date(System.currentTimeMillis() + expire))//过期时间
                .compact();
    }

    /**
     * 解析JWT令牌
     *
     * @param jwt JWT令牌
     * @return JWT第二部分负载 payload 中存储的内容
     */
    public static Claims parseJWT(String jwt) {
        return Jwts.parser()
                .setSigningKey(base64Key)//指定签名密钥
                .parseClaimsJws(jwt)//指定令牌Token
                .getBody();
    }
}
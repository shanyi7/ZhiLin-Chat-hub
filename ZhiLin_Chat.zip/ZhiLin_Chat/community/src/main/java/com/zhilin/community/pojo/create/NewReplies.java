package com.zhilin.community.pojo.create;


import lombok.Data;

/*添加新回复请求*/
@Data
public class NewReplies {
    private Integer userId;
    private Integer postId;
    private Integer commentId;
    private String content;
    private Integer parentRelyId;
}


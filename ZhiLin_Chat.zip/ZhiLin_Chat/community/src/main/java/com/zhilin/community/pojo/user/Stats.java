package com.zhilin.community.pojo.user;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*个人卡片部分统计数据*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Stats {
    private Long following;     //关注
    private Long followers;     //粉丝
    private Long points;        //积分
    private Long likes;         //点赞
    private Long views;         //浏览
}
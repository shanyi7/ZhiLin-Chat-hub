package com.zhilin.community.service;

import com.zhilin.community.pojo.response.PostResponse;
import com.zhilin.community.pojo.database.Post;


import java.time.Instant;
import java.util.List;

public interface PostService {

    /**
     * 获取关注用户的帖子列表
     *
     * @param nickname 用户ID
     * @return 返回查询结果
     */
    List<PostResponse> selectPostsList(String nickname, String content, Instant startTime, Instant endTime);

    /**
     * 获取关注用户的帖子列表
     *
     * @param userId 用户ID
     * @return 返回查询结果
     */
    List<PostResponse> selectFollowedPosts(Integer userId);

    /**
     * 获取热门帖子列表
     *
     * @param userId 用户ID
     * @return 返回查询结果
     */
    List<PostResponse> selectHotPosts(Integer userId);

    /**
     * 获取指定的帖子信息
     *
     * @param postId 帖子ID
     * @return 返回查询结果
     */
    PostResponse selectPostById(Integer postId);

    /**
     * 创建新帖子
     *
     * @param post 帖子
     */
    void createPost(Post post);

    /**
     * 统计帖子列表数目
     *
     * @return 返回查询结果
     */
    Integer countPosts();

    /**
     * 获取关注用户的帖子列表
     *
     * @param userId 用户ID
     * @return 返回查询结果
     */
    Long countFollowedPosts(Integer userId);

    List<PostResponse> selectPostsListByUserId(Integer userId);

    List<PostResponse> selectCollectionsPostList(Integer userId);
}

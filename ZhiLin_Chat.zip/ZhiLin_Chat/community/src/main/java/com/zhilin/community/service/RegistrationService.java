package com.zhilin.community.service;

import com.aventrix.jnanoid.jnanoid.NanoIdUtils;
import com.zhilin.community.pojo.database.Information;
import com.zhilin.community.pojo.database.User;
import com.zhilin.community.pojo.register.RegisterForm;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.Instant;

@Service
@Slf4j
@RequiredArgsConstructor
public class RegistrationService {
    private static final char[] DIGITS = "0123456789".toCharArray();
    private final UserService userService;
    private final PasswordEncoder passwordEncoder;

    @Transactional
    public User registerUser(RegisterForm form) throws Exception {
        // 生成用户基础信息
        User newUser = createBaseUser(form);
        // 创建关联信息
        Information userInfo = createUserProfile(newUser, form);
        // 持久化数据
        persistRegistrationData(newUser, userInfo);
        return newUser;
    }

    private User createBaseUser(RegisterForm form) {
        User user = new User();
        user.setChatNumber(generateNumericId());
        user.setPasswordHash(passwordEncoder.encode(form.getPassword()));
        user.setRegisterDate(Instant.now());
        user.setStatus("normal");
        user.setRole("user");
        user.setUserId(userService.getLatestID() + 1);
        return user;
    }

    private Information createUserProfile(User user, RegisterForm form) {
        Information info = new Information();
        info.setUserId(user);
        info.setNickname("User-" + user.getChatNumber());
        info.setPhoneNumber(form.getPhoneNumber());
        info.setEmail(form.getEmail());
        info.setGender("male");
        info.setFollowers(0L);
        info.setFollowing(0L);
        info.setPoints(0L);
        info.setLikes(0L);
        info.setViews(0L);
        return info;
    }

    private void persistRegistrationData(User user, Information info) throws Exception {
        try {
            userService.registerUserInfo(user);
            userService.registerRelateInfo(info);
            log.info("用户注册成功 - 社区账号: {}", user.getChatNumber());
        } catch (DataIntegrityViolationException e) {
            log.error("数据完整性冲突 - 账号: {}", user.getChatNumber(), e);
            throw new Exception("用户信息冲突，请检查输入数据");
        }
    }

    private String generateNumericId() {
        return NanoIdUtils.randomNanoId(new SecureRandom(), DIGITS, 10);
    }
}
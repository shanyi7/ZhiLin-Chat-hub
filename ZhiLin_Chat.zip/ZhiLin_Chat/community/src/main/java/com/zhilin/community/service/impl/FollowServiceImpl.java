package com.zhilin.community.service.impl;

import com.zhilin.community.mapper.FollowsMapper;
import com.zhilin.community.pojo.follows.FollowingData;
import com.zhilin.community.service.FollowService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class FollowServiceImpl implements FollowService {
    @Qualifier("followsMapper")
    @Autowired
    private FollowsMapper followsMapper;

    @Override
    public List<FollowingData> getFollowingData(int userId) {
        return followsMapper.getFollowingData(userId);
    }

    @Override
    public List<FollowingData> getFansData(int userId) {
        return followsMapper.getFansData(userId);
    }

    @Override
    public void addFollowData(int followerId, int followedId) {
        followsMapper.addFollowData(followerId, followedId);
    }

    @Override
    public void removeFollowData(int followerId, int followedId) {
        followsMapper.removeFollowData(followerId, followedId);
    }

    @Override
    public void updateFollowing(int followerId, int delta) {
        log.info("更新当前用户ID号为：{}的关注数量，数量{}", followerId, delta == 1 ? "加一" : "减一");
        followsMapper.updateFollowing(followerId, delta);
    }

    @Override
    public void updateFans(int followedId, int delta) {
        log.info("更新被关注用户ID号为：{}的粉丝数量，数量{}", followedId, delta == 1 ? "加一" : "减一");
        followsMapper.updateFans(followedId, delta);
    }
}

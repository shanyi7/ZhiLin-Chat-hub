package com.zhilin.community.pojo.user;

import lombok.Data;

@Data
public class BindRequest {
    private String chatNumber;
    private String account;
}

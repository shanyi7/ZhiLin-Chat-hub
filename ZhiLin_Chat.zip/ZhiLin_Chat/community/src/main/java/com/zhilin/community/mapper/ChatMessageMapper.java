package com.zhilin.community.mapper;

import com.zhilin.community.pojo.database.ChatMessage;
import org.apache.ibatis.annotations.*;


import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface ChatMessageMapper {
    // 动态条件查询
    @SelectProvider(type = MessageSqlBuilder.class, method = "buildMessageQuery")
    List<ChatMessage> selectMessages(
            @Param("userId") Long userId,
            @Param("contactId") Long contactId,
            @Param("startTime") LocalDateTime startTime
    );

    /**
     * 基于时间分页查询消息
     *
     * @param userId     当前用户ID
     * @param contactId  联系人ID
     * @param beforeTime 分页基准时间（不包含）
     * @param pageSize   每页条数
     */
    List<ChatMessage> selectMessagesBeforeTime(
            @Param("userId") Long userId,
            @Param("contactId") Long contactId,
            @Param("beforeTime") LocalDateTime beforeTime,
            @Param("pageSize") int pageSize
    );

    // 批量插入（优化性能）
    @Insert("<script>" +
            "INSERT INTO chat_message (session_id,sender_id, receiver_id, content,message_type, timestamp, status) VALUES " +
            "<foreach collection='list' item='msg' separator=','>" +
            "(#{msg.sessionId}, #{msg.senderId}, #{msg.receiverId}, #{msg.content}, #{msg.messageType},#{msg.timestamp}, #{msg.status})" +
            "</foreach>" +
            "</script>")
    void batchInsert(@Param("list") List<ChatMessage> messages);

    // 标记消息已读
    @Update("UPDATE chat_message SET  status = 'READ' " +
            "WHERE receiver_id = #{userId} AND sender_id = #{contactId} AND status = 'DELIVERED'")
    int markMessagesRead(@Param("userId") Long userId, @Param("contactId") Long contactId);

    @Select("SELECT id FROM chat_message ORDER BY id DESC LIMIT 1;")
    Long getLastMessagesID();
}


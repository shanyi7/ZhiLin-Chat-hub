package com.zhilin.community.mapper;

import com.zhilin.community.pojo.database.Likes;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import com.zhilin.community.pojo.database.Star;

@Mapper
public interface LikesMapper {

    @Insert("INSERT INTO likes(like_id, user_id, target_type, target_id, create_time) " +
            "VALUES(#{likeId},#{userId},#{targetType},#{targetId},#{createTime})")
    void insertLikes(Likes likes);

    @Delete("DELETE FROM likes WHERE user_id = #{userId} AND target_type = #{targetType} AND target_id = #{targetId}")
    void deleteLikes(Integer userId, String targetType, Integer targetId);

    @Select("SELECT count(*) FROM likes WHERE target_type = #{targetType} AND target_id = #{targetId}")
    int countLikes(String targetType, Integer targetId);

    @Insert("INSERT INTO stars(star_id,user_id, post_id,starred_at) " +
            "VALUES (#{starId},#{userId},#{postId},#{starredAt})")
    void insertStars(Star star);

    @Delete("DELETE FROM Stars WHERE user_id=#{userId} AND post_id=#{postId}")
    void deleteStars(Integer userId, Integer postId);

}

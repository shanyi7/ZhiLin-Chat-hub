package com.zhilin.community.mapper;

import com.zhilin.community.pojo.database.Information;
import com.zhilin.community.pojo.reset.ResetRequest;
import com.zhilin.community.pojo.user.UpdateForm;
import com.zhilin.community.pojo.database.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;

@Mapper
public interface UserMapper {
    //查询用户数据
    @Select("select * from users where chat_number = #{chatNumber} and password_hash= #{passwordHash}")
    User checkUserByChatNumber(String chatNumber, String passwordHash);

    @Select("select * from users JOIN information info ON  users.user_id = info.user_id where info.phone_number = #{phoneNumber} and users.password_hash= #{passwordHash}")
    User checkUserByPhoneNumber(String phoneNumber, String passwordHash);

    @Select("select * from users JOIN information info ON  users.user_id = info.user_id where info.email = #{email} and users.password_hash= #{passwordHash}")
    User checkUserByEmail(String email, String passwordHash);

    @Select("select * from users where chat_number = #{chatNumber}")
    User findUserByChatNumber(String chatNumber);

    @Select("select * from users JOIN information info ON  users.user_id = info.user_id where info.phone_number = #{phoneNumber}")
    User findUserByPhoneNumber(String phoneNumber);

    @Select("select * from users JOIN information info ON  users.user_id = info.user_id where info.email = #{email}")
    User findUserByEmail(String email);

    //通过社区账号查询关联信息
    Information getInformationByChatNumber(String chatNumber);

    //插入用户信息
    void addUserInfo(User user);

    //插入相关的个人信息
    void addRelateInfo(Information information);

    //验证邮箱是否被注册
    boolean checkEmailExists(String email);

    //验证手机号是否被注册
    @Select("SELECT EXISTS(SELECT 1 FROM information WHERE phone_number = #{phoneNumber})")
    boolean checkPhoneNumberExists(String phoneNumber);

    //获取用户信息通过社区账号
    @Select("SELECT * from users where chat_number = #{chatNumber}")
    User getUserByChatNumber(String chatNumber);

    @Select("SELECT * from users where user_id = #{userId}")
    User getUserByID(int userId);

    //更新用户密码
    @Update("UPDATE users set password_hash = #{passwordHash} where chat_number = #{chatNumber}")
    boolean updatePassword(ResetRequest resetRequest);

    @Select("SELECT * from information where user_id = #{user.id}")
    Information getInformationByUserId(int userId);

    @Select("SELECT user_id FROM users ORDER BY user_id DESC LIMIT 1;")
    int getLatestID();

    @Update("update information info JOIN users ON info.user_id=users.user_id set avatar_url=#{avatarUrl} where users.chat_number=#{chatNumber}")
    boolean updateAvatarUrl(String avatarUrl, String chatNumber);

    boolean updateInfo(UpdateForm updateForm);

    @Select("SELECT users.chat_number FROM users JOIN information  info ON users.user_id = info.user_id WHERE info.email = #{email}")
    String getChatNumberByEmail(String email);

    @Update("UPDATE information info JOIN users ON users.user_id = info.user_id SET info.email = #{email} WHERE users.chat_number = #{chatNumber}")
    boolean updateEmail(String email, String chatNumber);

    @Update("UPDATE users SET last_login = #{lastLogin} WHERE chat_number = #{chatNumber}")
    void updateLastLogin(Instant lastLogin, String chatNumber);

    List<Information> selectAllInformation(String nickname, String gender, String community);

    @Select("SELECT * FROM users")
    List<User> selectAllUsers();

    @Update("UPDATE users SET password_hash = #{passwordHash} WHERE chat_number = #{chatNumber}")
    void updateUserPassword(String chatNumber, String passwordHash);

    List<User> selectAccountList(String chatNumber, String status, Instant startTime, Instant endTime);

    void updateAccountStatus(Integer userId, String status);

    void deleteAccountById(Integer userId);

    @Select("SELECT * FROM users " +
            "WHERE chat_number = #{chatNumber}  AND role = 'admin'")
    User  checkAdminByChatNumber(String chatNumber);
}
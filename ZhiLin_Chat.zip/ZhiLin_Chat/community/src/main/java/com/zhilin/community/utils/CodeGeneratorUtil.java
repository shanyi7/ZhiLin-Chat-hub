package com.zhilin.community.utils;

import java.security.SecureRandom;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class CodeGeneratorUtil {
    //"ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    private static final String CHAR_SET = "0123456789";

    public static String generateRandomCode(int length) {
        SecureRandom random = new SecureRandom();
        return IntStream.range(0, length)
                .mapToObj(i -> String.valueOf(CHAR_SET.charAt(random.nextInt(CHAR_SET.length()))))
                .collect(Collectors.joining());
    }
}
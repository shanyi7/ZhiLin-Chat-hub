package com.zhilin.community.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zhilin.community.pojo.database.ChatMessage;
import com.zhilin.community.pojo.database.Notification;
import com.zhilin.community.pojo.message.MessageRequest;
import com.zhilin.community.service.ChatMessageService;
import com.zhilin.community.service.NotificationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Controller
public class ChatController {

    @Autowired
    private ChatMessageService chatService;
    @Autowired
    private NotificationService notificationService;
    @Autowired
    private SimpMessagingTemplate messagingTemplate;
    @Autowired
    private ObjectMapper objectMapper;

    private static ChatMessage buildChatMessage(MessageRequest messageRequest) {
        Instant timestamp = Instant.parse(messageRequest.getTimestamp());
        ChatMessage chatMessage = new ChatMessage();
        chatMessage.setMessageType(messageRequest.getMessageType());
        chatMessage.setContent(messageRequest.getContent());
        chatMessage.setContent(messageRequest.getContent());
        chatMessage.setSenderId(messageRequest.getSenderId());
        chatMessage.setReceiverId(messageRequest.getReceiverId());
        chatMessage.setTimestamp(timestamp);
        chatMessage.setStatus(messageRequest.getStatus());
        return chatMessage;
    }

    private static Notification buildNotification(ChatMessage chatMessage) {
            Notification newNotify = new Notification();
            newNotify.setUserId(chatMessage.getReceiverId());
            newNotify.setTriggerUserId(chatMessage.getSenderId());
            newNotify.setTargetType("message");
            newNotify.setTargetId(chatMessage.getId().intValue());
            newNotify.setActionType("message");
            newNotify.setContent(chatMessage.getContent());
            newNotify.setIsRead(0);
            newNotify.setCreateTime(chatMessage.getTimestamp());
            return newNotify;
    }
    @MessageMapping("/sendMessage")
    public void handleMessage(@Payload MessageRequest messageRequest) {

        // 构建消息实体
        ChatMessage chatMessage = buildChatMessage(messageRequest);

        try {
            // 1. 保存消息到数据库
            chatMessage.setStatus("DELIVERED");
            Long curID = chatService.saveMessage(chatMessage);
            chatMessage.setId(curID);

            //生成新通知插入至通知表
//            Notification newNotify = buildNotification(chatMessage);
//            notificationService.notify(newNotify);

            // 2. 发送 ACK 确认给发送方（消息已持久化）
            Map<String, Object> ackData = new HashMap<>();
            ackData.put("tempId", messageRequest.getTempId());      // 前端生成的临时ID
            ackData.put("status", "delivered");                     // 消息状态
            ackData.put("sessionId", chatMessage.getSessionId());   // 会话ID

            String senderId = messageRequest.getSenderId().toString();
            String receiverId = messageRequest.getReceiverId().toString();
            String content = objectMapper.writeValueAsString(ackData);

            // 通过用户专属队列发送 ACK
            messagingTemplate.convertAndSendToUser(senderId, "/queue/ack", content);

            log.info("[ACK] 确认消息已发送至发送方用户：{}，队列路径为：/user/{}/queue/ack，发送内容为：{}", senderId, senderId, content);

            // 3. 发送消息给接收方
            messagingTemplate.convertAndSendToUser(receiverId, "/queue/messages", chatMessage);

            log.info("[MESSAGE] 点对点新消息已转发至用接收方用户：{}，队列路径为：/user/{}/queue/messages，转发内容为：{}", receiverId, receiverId, chatMessage);
        } catch (JsonProcessingException e) {
            // 处理序列化异常
            log.error("ACK 序列化失败", e);
        }
    }
}


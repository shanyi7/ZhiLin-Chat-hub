package com.zhilin.community.pojo.user;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/*修改个人资料表单*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UpdateForm {
    private String chatNumber;          //社区账号
    private String nickname;            //昵称
    private String avatarUrl;           //头像URL
    private String gender;              //性别
    private String briefing;            //简介
    private String district;            //地区
    private LocalDate birthday;         //生日
    private String community;           //隶属社区
    private String address;             //详细地址
}

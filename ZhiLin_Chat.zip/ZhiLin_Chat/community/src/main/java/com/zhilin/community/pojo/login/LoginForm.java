package com.zhilin.community.pojo.login;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/*前端登录界面表单*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginForm {
    private String account;         //账号：社区账号/手机号/邮箱
    private String password;    //密码
    private String captcha;         //图形验证码
}

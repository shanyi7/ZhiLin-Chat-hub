package com.zhilin.community.config;

import com.google.code.kaptcha.impl.DefaultKaptcha;
import com.google.code.kaptcha.util.Config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Properties;

@Configuration
public class KaptchaConfig {
    @Bean
    public DefaultKaptcha kaptchaProducer() {
        DefaultKaptcha kaptcha = new DefaultKaptcha();
        Properties props = new Properties();
        props.setProperty("kaptcha.image.width", "120");
        props.setProperty("kaptcha.image.height", "50");
        props.setProperty("kaptcha.textproducer.char.length", "4");
        props.setProperty("kaptcha.textproducer.font.color", "blue");
        props.setProperty("kaptcha.noise.color", "black");  // 设置干扰线颜色
        props.setProperty("kaptcha.noise.line.num", "3");   // 干扰线数量(默认2)
        props.setProperty("kaptcha.background.impl", "com.google.code.kaptcha.impl.DefaultBackground");
        props.setProperty("kaptcha.background.clear.from", "220,220,220"); // 渐变浅灰
        props.setProperty("kaptcha.background.clear.to", "180,180,180");   // 渐变深灰
        props.setProperty("kaptcha.textproducer.char.string", "ABCDEFGHJKLMNPQRSTUVWXYZ23456789");
        props.setProperty("kaptcha.textproducer.font.names", "Arial,Arial Narrow,Serif,Helvetica,Tahoma,Times New Roman,Verdana");
        Config config = new Config(props);
        kaptcha.setConfig(config);
        return kaptcha;
    }
}
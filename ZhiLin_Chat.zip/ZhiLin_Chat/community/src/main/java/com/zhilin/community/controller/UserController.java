package com.zhilin.community.controller;

import com.github.pagehelper.PageInfo;
import com.zhilin.community.pojo.*;
import com.zhilin.community.pojo.database.Information;
import com.zhilin.community.pojo.database.User;
import com.zhilin.community.pojo.follows.FollowingData;
import com.zhilin.community.pojo.page.PageResult;
import com.zhilin.community.pojo.session.NewSession;
import com.zhilin.community.pojo.user.BindRequest;
import com.zhilin.community.pojo.user.UpdateForm;
import com.zhilin.community.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.Date;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    AccountService accountService;
    @Autowired
    private UserService userService;
    @Autowired
    private InformationService informationService;
    @Autowired
    private RelationService relationService;
    @Autowired
    private FollowService followService;

    @GetMapping("/profile/{chatNumber}")
    public Result getUserProfile(@PathVariable String chatNumber) {
        Information profileInfo = userService.getInformationByChatNumber(chatNumber);
        if (profileInfo != null) {
            return Result.success(profileInfo.getProfile());
        }
        return Result.error("获取用户信息失败");
    }

    @GetMapping("/stats/{chatNumber}")
    public Result getUserStats(@PathVariable String chatNumber) {
        Information profileInfo = userService.getInformationByChatNumber(chatNumber);
        if (profileInfo != null) {
            return Result.success(profileInfo.getStats());
        }
        return Result.error("获取用户信息失败");
    }

    @GetMapping("/info/{chatNumber}")
    public Result getUserInfo(@PathVariable String chatNumber) {
        Information profileInfo = userService.getInformationByChatNumber(chatNumber);
        if (profileInfo != null) {
            return Result.success(profileInfo.getDetails());
        }
        return Result.error("获取用户信息失败");
    }

    @PutMapping("/update")
    public Result updateUserInfo(@RequestBody UpdateForm updateForm) {
        boolean res = userService.updateInfo(updateForm);
        return res ? Result.success("更新用户资料成功") : Result.error("更新用户资料失败");
    }

    //核验用户社区账号是否存在接口
    @GetMapping("/check")
    public Result check(@RequestParam String account) {
        User user = userService.getUserByChatNumber(account);
        if (user != null) {
            Information profileInfo = userService.getInformationByChatNumber(user.getChatNumber());
            NewSession session = profileInfo.getNewSession();
            session.setUserId(user.getUserId());
            session.setChatNumber(account);
            return Result.success(session);
        }
        return Result.error("当前用户不存在");
    }

    @GetMapping("/session")
    public Result getSessionIfo(@RequestParam int targetUserId) {
//        int userId = Integer.parseInt(targetUserId);
        System.out.println(targetUserId);
        Information profileInfo = userService.getInformationByUserId(targetUserId);
        NewSession session = profileInfo.getNewSession();
        String account = userService.getUserByID(targetUserId).getChatNumber();
        session.setUserId(targetUserId);
        session.setChatNumber(account);
        return Result.success(session);
    }

    //邮箱绑定接口
    @PostMapping("/bind")
    public Result changeBind(@RequestBody BindRequest request) {
        boolean res = userService.updateEmail(request.getAccount(), request.getChatNumber());
        return res ? Result.success("账号绑定成功") : Result.error("账号绑定失败");
    }


    @GetMapping("/following")
    public Result getFollowing(@RequestParam int userId) {
        List<FollowingData> followingDataList = followService.getFollowingData(userId);
        return Result.success(followingDataList);
    }

    @GetMapping("/followers")
    public Result getFans(@RequestParam int userId) {
        List<FollowingData> fansDataList = followService.getFansData(userId);
        return Result.success(fansDataList);
    }

    //用户关注操作
    @PostMapping("/follow/{followedId}")
    public Result setFollowing(@RequestBody Map<String, Integer> requestBody, @PathVariable int followedId) {
        int followerId = requestBody.get("followerId");
        System.out.println("followerId: " + followerId + "--followedId: " + followedId);
        relationService.setFollowing(followerId, followedId);
        return Result.success("关注成功");
    }

    //用户取关操作
    @DeleteMapping("/follow/{followedId}")
    public Result deleteFollowing(@RequestParam int followerId, @PathVariable int followedId) {
        System.out.println("followerId: " + followerId + "--followedId: " + followedId);
        relationService.cancelFollowing(followerId, followedId);
        return Result.success();
    }

    @GetMapping("/accounts")
    public Result getAccounts(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String chatNumber,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate
    ) {
        Instant startInstant = null;
        Instant endInstant = null;

        if (startDate != null) {
            startInstant = startDate.atStartOfDay(ZoneOffset.UTC).toInstant();
        }

        if (endDate != null) {
            endInstant = endDate.atTime(23, 59, 59, 999_999_999)
                    .atZone(ZoneOffset.UTC)
                    .toInstant();
        }

        // 调用service方法时传递转换后的Instant
        PageInfo<User> pageInfo = accountService.getUsersAccount(pageNum, pageSize, chatNumber, status, startInstant, endInstant);
        return Result.success(pageInfo);
    }

    @GetMapping("/info")
    public Result getUsersInfo(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String nickname,
            @RequestParam(required = false) String gender,
            @RequestParam(required = false) String community
    ) {
        PageInfo<Information> pageInfo = informationService.getUsersInfo(pageNum, pageSize, nickname, gender, community);
        return Result.success(pageInfo);
    }
}


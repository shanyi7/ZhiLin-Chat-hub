package com.zhilin.community.pojo.database;


import lombok.*;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Notification {
    private Integer notificationId;
    private Integer userId;
    private Integer triggerUserId;
    private String targetType;
    private Integer targetId;
    private String actionType;
    private String content;
    private Integer isRead;
    private Instant createTime;

}
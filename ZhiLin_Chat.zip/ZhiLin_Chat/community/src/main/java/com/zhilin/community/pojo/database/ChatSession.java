package com.zhilin.community.pojo.database;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

import java.time.Instant;

@Getter
@Setter
@Entity
@Table(name = "chat_session")
public class ChatSession {
    @Id
    @Column(name = "id", nullable = false, length = 64)
    private String id;

    @Column(name = "user_id", nullable = false)
    private Integer userId;

    @Column(name = "contact_id", nullable = false)
    private Integer contactId;

    @Lob
    @Column(name = "last_message")
    private String lastMessage;

    @ColumnDefault("0")
    @Column(name = "unread_count")
    private Integer unreadCount;

    @Column(name = "last_active_time")
    private Instant lastActiveTime;

    private String contactAvatarUrl;

    private String contactNickname;

}
package com.zhilin.community.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.zhilin.community.mapper.UserMapper;
import com.zhilin.community.pojo.database.Information;
import com.zhilin.community.pojo.database.User;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
public class AccountService {
    @Resource
    UserMapper userMapper;

    public PageInfo<User> getUsersAccount(Integer pageNum, Integer pageSize,
                                          String chatNumber, String status, Instant startTime, Instant endTime) {
        PageHelper.startPage(pageNum, pageSize);
        List<User> accounts = userMapper.selectAccountList(chatNumber, status, startTime, endTime);
        return new PageInfo<>(accounts);
    }
}

package com.zhilin.community.controller;

import com.github.pagehelper.PageInfo;
import com.zhilin.community.pojo.response.CommentsResponse;
import com.zhilin.community.pojo.create.NewComments;
import com.zhilin.community.pojo.response.PostResponse;
import com.zhilin.community.pojo.Result;
import com.zhilin.community.service.CommentsService;
import com.zhilin.community.service.DynamicService;
import com.zhilin.community.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.List;


@RestController
@RequestMapping("/posts")
public class PostController {

    @Autowired
    private PostService postService;

    @Autowired
    private DynamicService dynamicService;

    @Autowired
    private CommentsService commentsService;


    @GetMapping("/all")
    public Result getHotPosts(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String nickname,
            @RequestParam(required = false) String content,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate
    ) {
        Instant startInstant;
        startInstant = null;
        Instant endInstant = null;

        if (startDate != null) {
            startInstant = startDate.atStartOfDay(ZoneOffset.UTC).toInstant();
        }

        if (endDate != null) {
            endInstant = endDate.atTime(23, 59, 59, 999_999_999)
                    .atZone(ZoneOffset.UTC)
                    .toInstant();
        }
        PageInfo<PostResponse> pageInfo = dynamicService.getAllPosts(pageNum, pageSize, nickname, content, startInstant, endInstant);
        return Result.success(pageInfo);
    }


    //获取关注用户发表的帖子列表
    @GetMapping("/followed")
    public Result getFollowedPosts(
            @RequestParam Integer userId,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer pageSize) {

        PageInfo<PostResponse> pageInfo = dynamicService.getFollowedPosts(userId, page, pageSize);
        return Result.success(pageInfo);
    }

    //获取社区热门的帖子列表
    @GetMapping("/hot")
    public Result getHotPosts(
            @RequestParam(required = false) Integer userId,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer pageSize) {

        PageInfo<PostResponse> pageInfo = dynamicService.getHotPosts(userId, page, pageSize);
        return Result.success(pageInfo);
    }

    //获取个人所发布的帖子列表
    @GetMapping("/self")
    public Result getSelfPosts(
            @RequestParam Integer userId,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<PostResponse> pageInfo = dynamicService.getSelfPosts(userId, pageNum, pageSize);
        return Result.success(pageInfo);
    }

    //获取个人的收藏夹帖子列表
    @GetMapping("/collections")
    public Result getCollectionsPosts(
            @RequestParam Integer userId,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<PostResponse> pageInfo = dynamicService.getCollectionsPosts(userId, pageNum, pageSize);
        return Result.success(pageInfo);
    }

    //获取单条帖子的详细信息，用户帖子详情页
    @GetMapping("/{postId}")
    public Result getPost(@PathVariable Integer postId) {
        PostResponse response = postService.selectPostById(postId);
        return Result.success(response);
    }

    @PostMapping(value = "/create/{userId}", consumes = "multipart/form-data")
    public Result createPost(@RequestParam("content") String content,
                             @RequestParam(value = "images", required = false) List<MultipartFile> images,
                             @PathVariable Integer userId) throws IOException {
        PostResponse response = dynamicService.createPost(content, images, userId);
        return Result.success(response);
    }

    //获取对应的帖子的评论列表
    @GetMapping("/comments")
    public Result getComments(@RequestParam Integer userId,
                              @RequestParam Integer postId,
                              @RequestParam(defaultValue = "1") Integer page,
                              @RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<CommentsResponse> pageInfo = commentsService.getCommentsList(userId, postId, page, pageSize);
        return Result.success(pageInfo);
    }

    @PostMapping("/send-comments")
    public Result addComment(@RequestBody NewComments newComments) {
        commentsService.insertComment(newComments.getUserId(), newComments.getPostId(), newComments.getContent());
        return Result.success();
    }
}

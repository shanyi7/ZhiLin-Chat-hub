package com.zhilin.community.websocket;

import com.zhilin.community.pojo.session.SessionState;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.user.SimpUserRegistry;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

import java.util.Collection;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class SessionManager {
    @Autowired
    private SimpUserRegistry userRegistry;
    private static final ConcurrentHashMap<String, SessionState> sessionMap = new ConcurrentHashMap<>(512);

    // 新连接建立时记录会话
//    @EventListener
//    public void handleSessionConnected(SessionConnectedEvent event) {
//        StompHeaderAccessor accessor = StompHeaderAccessor.wrap(event.getMessage());
//        String sessionId = accessor.getSessionId();
//        String userId = accessor.getUser().getName();
//        String deviceInfo = accessor.getNativeHeader("User-Agent").get(0);
//
//        sessionMap.put(sessionId, new SessionState(
//                sessionId,
//                userId,
//                deviceInfo,
//                System.currentTimeMillis()
//        ));
//    }

    // 连接断开时清理会话
    @EventListener
    public void handleSessionDisconnect(SessionDisconnectEvent event) {
        String sessionId = event.getSessionId();
        sessionMap.remove(sessionId);
    }

    // 更新会话活跃时间（需在消息到达时调用）
    public void updateSessionActivity(String sessionId) {
        sessionMap.computeIfPresent(sessionId, (k, v) -> {
            v.setLastActive(System.currentTimeMillis());
            return v;
        });
    }

    // 获取所有会话（线程安全）
    public Collection<SessionState> getSessions() {
        return Collections.unmodifiableCollection(sessionMap.values());
    }
}
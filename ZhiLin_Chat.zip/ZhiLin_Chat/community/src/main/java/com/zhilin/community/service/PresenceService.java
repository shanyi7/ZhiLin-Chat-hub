package com.zhilin.community.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class PresenceService {

    @Autowired
    RelationService relationService;
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;
    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    // 更新在线状态
    public void updatePresence(Long userId, boolean online) {
        String key = "presence:user:" + userId;
        if (online) {
            redisTemplate.opsForValue().set(key, "online"); // TTL 5分钟
        } else {
            redisTemplate.delete(key);
        }
        List<Long> friendIds = relationService.getFriendIds(userId);
        friendIds.forEach(friendId ->
                notifyUserPresence(friendId, userId, online)
        );
        log.info("用户ID为：{}的用户成功修改在线状态为：{}", userId, online ? "在线" : "离线");
        log.info("已成功将状态更新信息通知该用户相关的好友，好友列表为：{}", Arrays.toString(friendIds.toArray()));
    }

    // 批量获取在线状态
    public Map<Long, Boolean> getBulkPresence(List<Long> userIds) {
        return userIds.stream().collect(Collectors.toMap(
                userId -> userId,
                userId -> redisTemplate.hasKey("presence:user:" + userId)
        ));
    }

    private void notifyUserPresence(Long targetUserId, Long changedUserId, boolean online) {
        messagingTemplate.convertAndSendToUser(
                targetUserId.toString(),
                "/queue/presence",
                Map.of(
                        "userId", changedUserId,
                        "status", online ? "online" : "offline"
                )
        );
    }
}
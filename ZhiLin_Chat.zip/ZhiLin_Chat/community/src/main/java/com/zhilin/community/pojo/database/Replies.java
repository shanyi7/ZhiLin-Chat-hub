package com.zhilin.community.pojo.database;

import lombok.Data;

import java.time.Instant;

@Data
public class Replies {
    private Integer replyId;
    private String content;
    private Instant releaseDate;
    private Integer likes;
    private Integer userId;
    private Integer postId;
    private Integer parentCommentId;
    private Integer parentRelyId;
}

package com.zhilin.community.pojo.session;

import lombok.Data;

/*新会话列表的响应*/
@Data
public class NewSession {
    private int userId;              //新会话的contact用户userId
    private String chatNumber;      //社区账号
    private String nickname;        //昵称
    private String avatarUrl;       //头像URL
}

package com.zhilin.community.controller;

import com.github.pagehelper.PageInfo;
import com.zhilin.community.pojo.*;
import com.zhilin.community.pojo.database.Declaration;
import com.zhilin.community.pojo.notify.DeclareNotify;
import com.zhilin.community.pojo.notify.InteractionNotify;
import com.zhilin.community.pojo.notify.LikeNotify;
import com.zhilin.community.pojo.request.MarkNotifyReadRequest;
import com.zhilin.community.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notify")
public class NotificationController {
    //新增通知的情况有：
    // 1.评论操作执行后
    //2.点赞操作执行后
    //3.回复操作执行后
    //4.收到新私信后
    @Autowired
    private NotificationService notificationService;

    @GetMapping("/interactions")
    public Result getInteractionNotify(@RequestParam int userId,
                                       @RequestParam String type,
                                       @RequestParam(defaultValue = "1") Integer pageNum,
                                       @RequestParam(defaultValue = "5") Integer pageSize) {
        type = type.equals("all") ? null : type;
        PageInfo<InteractionNotify> notifyList = notificationService.getInteractionNotify(userId, type, pageNum, pageSize);
        return Result.success(notifyList);
    }

    @GetMapping("/likes")
    public Result getLikeNotify(@RequestParam int userId,
                                @RequestParam String type,
                                @RequestParam(defaultValue = "1") Integer pageNum,
                                @RequestParam(defaultValue = "5") Integer pageSize) {
        type = type.equals("all") ? null : type;
        PageInfo<LikeNotify> notifyList = notificationService.getLikeNotify(userId, type, pageNum, pageSize);
        return Result.success(notifyList);
    }

    @GetMapping("/system")
    public Result getSystemNotify() {
        String type = null;
        List<DeclareNotify> notifyList = notificationService.getDeclareNotify(type);
        return Result.success(notifyList);
    }

    @GetMapping("/declare")
    public Result getLikeNotify(@RequestParam(required = false) String title,
                                @RequestParam(defaultValue = "1") Integer pageNum,
                                @RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<Declaration> declarationPageInfo = notificationService.getAllDeclarations(title, pageNum, pageSize);
        return Result.success(declarationPageInfo);
    }

    @GetMapping("/unread-counts")
    public Result getUnreadCounts(@RequestParam int userId) {
        return Result.success(notificationService.getUnreadCounts(userId));
    }

    @PutMapping("/mark-as-read")
    public Result markNotificationsAsRead(@RequestBody MarkNotifyReadRequest request) {
        notificationService.markNotificationsAsRead(request.getUserId(), request.getNotifyType());
        return Result.success(request.getNotifyType() + "未读通知标为已读成功！");
    }
}

package com.zhilin.community.pojo.login;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*登录成功响应*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginResponse {
    private String token;           //jwt令牌token
    private UserInfo userInfo;      //前端各界面所需的部分共享信息：用户userId，社区账号，头像URL
}

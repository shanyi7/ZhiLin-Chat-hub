package com.zhilin.community.pojo.database;

//import com.baomidou.mybatisplus.annotation.TableField;
//import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.Instant;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "posts")
public class Post {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "post_id", nullable = false)
    private Integer postId;

    @Lob
    @Column(name = "content", nullable = false)
    private String content;

    @Lob
    @Column(name = "images")
//    @TableField(typeHandler = JacksonTypeHandler.class) // MyBatis Plus JSON 处理器
//    private String images; // 图片URL列表
    private List<String> images; // 图片URL列表

    @Column(name = "release_date", nullable = false)
    private Instant releaseDate;

    @ColumnDefault("0")
    @Column(name = "likes")
    private Integer likes;

    @ColumnDefault("0")
    @Column(name = "comments")
    private Integer comments;

    @ColumnDefault("0")
    @Column(name = "stars")
    private Integer stars;

//    @ManyToOne(fetch = FetchType.LAZY, optional = false)
//    @OnDelete(action = OnDeleteAction.CASCADE)
//    @JoinColumn(name = "user_id", nullable = false)
//    private User userId;
    private Integer userId;


}
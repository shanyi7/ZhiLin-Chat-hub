package com.zhilin.community.service;

import com.zhilin.community.mapper.ChatMessageMapper;
import com.zhilin.community.pojo.database.ChatMessage;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ChatMessageService {
    private final ChatMessageMapper messageMapper;
    private final ChatSessionService sessionService;

    // 发送消息（事务操作）
    @Transactional
    public Long saveMessage(ChatMessage message) {
        String senderSessionId = message.getSenderId() + "_" + message.getReceiverId();                //属于主动发起方的sessionId
        String receiverSessionId = message.getReceiverId() + "_" + message.getSenderId();
        message.setSessionId(senderSessionId);
        // 1. 插入消息
        messageMapper.batchInsert(Collections.singletonList(message));
        // 2. 更新会话（+1未读）
        sessionService.updateSession(senderSessionId, message.getContent(), message.getTimestamp(), 0);
        sessionService.updateSession(receiverSessionId, message.getContent(), message.getTimestamp(), 1);
        return messageMapper.getLastMessagesID();
    }

    // 获取聊天记录（动态查询）
    public List<ChatMessage> getMessageHistory(Long userId, Long contactId, LocalDateTime beforeTime, int size) {
        // 如果首次加载，获取当前时间
        if (beforeTime == null) {
            beforeTime = LocalDateTime.now();
        }

        return messageMapper.selectMessagesBeforeTime(userId, contactId, beforeTime, size);
    }

    // 批量标记已读（优化性能）
    @Transactional
    public void batchMarkRead(Long userId, Long contactId) {
        // 1. 更新消息状态
        int count = messageMapper.markMessagesRead(userId, contactId);
        // 2. 更新会话未读数（原子减少）
        sessionService.updateSessionRead(generateSessionId(userId, contactId), -count);
    }

    private String generateSessionId(Long user1, Long user2) {
        return user1 + "_" + user2;
    }
//    private String generateSessionId(Long user1, Long user2) {
//        return user1 < user2 ? user1 + "_" + user2 : user2 + "_" + user1;
//    }
}
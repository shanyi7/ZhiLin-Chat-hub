package com.zhilin.community.pojo.notify;

import lombok.Data;

import java.time.Instant;

/*系统通知*/
@Data
public class DeclareNotify {
    private Integer notificationId;
    private Integer userId;
    private Integer triggerUserId;
    private String targetType;
    private Integer targetId;
    private String actionType;
    private String title;
    private String content;
    private Integer isRead;
    private Instant createTime;
}

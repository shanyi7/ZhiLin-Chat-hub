package com.zhilin.community.service;

import com.zhilin.community.mapper.ChatSessionMapper;
import com.zhilin.community.mapper.FollowsMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class RelationService {
    @Autowired
    ChatSessionMapper sessionMapper;

    @Autowired
    FollowService followService;

    // 获取用户的已有所有好友ID列表
    public List<Long> getFriendIds(Long userId) {
        return sessionMapper.selectContactIdsByUserId(userId);
    }

    //添加关注操作事务
    @Transactional
    public void setFollowing(int followerId, int followedId) {
        followService.addFollowData(followerId, followedId);
        followService.updateFollowing(followerId, 1);
        followService.updateFans(followedId, 1);
    }

    //取消关注操作事务
    @Transactional
    public void cancelFollowing(int followerId, int followedId) {
        followService.updateFollowing(followerId, -1);
        followService.updateFans(followedId, -1);
        followService.removeFollowData(followerId, followedId);
    }

}
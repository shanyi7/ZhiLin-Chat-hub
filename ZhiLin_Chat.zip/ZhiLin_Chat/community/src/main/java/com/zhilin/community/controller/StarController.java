package com.zhilin.community.controller;

import com.zhilin.community.pojo.Result;
import com.zhilin.community.pojo.request.StarRequest;
import com.zhilin.community.service.LikeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/star")
public class StarController {
    @Autowired
    private LikeService likeService;

    @PostMapping("/toggle")
    public Result toggleLike(@RequestBody StarRequest request) {
        likeService.toggleStar(request.getUserId(), request.getPostId(), request.getAction());
        return Result.success();
    }
}

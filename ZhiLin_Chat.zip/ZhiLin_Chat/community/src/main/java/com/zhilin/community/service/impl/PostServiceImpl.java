package com.zhilin.community.service.impl;

import com.zhilin.community.mapper.PostMapper;
import com.zhilin.community.pojo.response.PostResponse;
import com.zhilin.community.pojo.database.Post;
import com.zhilin.community.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
public class PostServiceImpl implements PostService {

    @Autowired
    private PostMapper postMapper;

    @Override
    public List<PostResponse> selectPostsList(String nickname, String content, Instant startTime, Instant endTime) {
        return postMapper.selectPostsList(nickname, content, startTime, endTime);
    }

    @Override
    public List<PostResponse> selectFollowedPosts(Integer userId) {
        return postMapper.selectFollowedPosts(userId);
    }

    @Override
    public List<PostResponse> selectHotPosts(Integer userId) {
        return postMapper.selectHotPosts(userId);
    }

    @Override
    public PostResponse selectPostById(Integer postId) {
        return postMapper.selectPostById(postId);
    }

    @Override
    public void createPost(Post post) {
        postMapper.insertPost(post);
    }

    @Override
    public Integer countPosts() {
        return postMapper.countPosts();
    }

    @Override
    public Long countFollowedPosts(Integer userId) {
        return postMapper.countFollowedPosts(userId);
    }

    @Override
    public List<PostResponse> selectPostsListByUserId(Integer userId) {
        return postMapper.selectPostsListByUserId(userId);
    }

    @Override
    public List<PostResponse> selectCollectionsPostList(Integer userId) {
        return postMapper.selectCollectionsPostList(userId);
    }


}

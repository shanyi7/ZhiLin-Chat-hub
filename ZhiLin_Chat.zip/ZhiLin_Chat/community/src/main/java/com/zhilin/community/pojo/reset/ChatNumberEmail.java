package com.zhilin.community.pojo.reset;

import lombok.Data;

/*找回密码及安全绑定部分*/
/*社区账号和邮箱核验*/
@Data
public class ChatNumberEmail {
    private String account;         //邮箱号
    private String ChatNumber;      //社区账号
}

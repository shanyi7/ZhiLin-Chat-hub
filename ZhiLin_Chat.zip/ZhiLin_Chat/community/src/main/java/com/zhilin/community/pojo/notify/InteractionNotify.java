package com.zhilin.community.pojo.notify;

import lombok.Data;

import java.time.Instant;

/*互动消息通知（评论及回复）*/
@Data
public class InteractionNotify {
    private Integer notificationId;
    private Integer userId;
    private Integer triggerUserId;
    private String nickname;
    private String avatarUrl;
    private String targetType;
    private Integer targetId;
    private String actionType;
    private String content;
    private String sourceContent;
    private Integer isRead;
    private Instant createTime;
}

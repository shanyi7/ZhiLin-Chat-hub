package com.zhilin.community.pojo.database;

import lombok.Data;

import java.time.Instant;

/*系统公告*/
@Data
public class Declaration {
    private Integer declareId;
    private String title;
    private String content;
    private String noticeType;
    private Instant createTime;
    private String nickname;
}

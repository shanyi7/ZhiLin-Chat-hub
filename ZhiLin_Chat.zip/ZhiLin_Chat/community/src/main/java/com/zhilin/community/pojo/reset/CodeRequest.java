package com.zhilin.community.pojo.reset;

import lombok.Data;

/*找回密码部分判断验证方式*/
@Data
public class CodeRequest {
    private String account;         // 手机号或邮箱
    private String type;            // 验证方式：email/sms
    private String kind;            //验证码用途：重置密码/账号安全绑定
}
package com.zhilin.community.mapper;

import com.zhilin.community.pojo.database.Declaration;
import com.zhilin.community.pojo.database.Notification;
import com.zhilin.community.pojo.notify.DeclareNotify;
import com.zhilin.community.pojo.notify.InteractionNotify;
import com.zhilin.community.pojo.notify.LikeNotify;
import com.zhilin.community.pojo.notify.NotifyCount;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface NotificationsMapper {
    void addNotification(Notification notification);

    List<InteractionNotify> selectInteractionNotifyByUserId(int userId, @Param("actionType") String type);

    List<LikeNotify> selectLikeNotifyByUserId(int userId, @Param("targetType") String type);

    NotifyCount selectNotifyCountByUserId(int userId);

    List<DeclareNotify> selectDeclarationsByType(@Param("targetType") String type);

    void markNotificationsAsRead(int userId, String notifyType);

    List<Declaration> selectAllDeclarations(String title);
}

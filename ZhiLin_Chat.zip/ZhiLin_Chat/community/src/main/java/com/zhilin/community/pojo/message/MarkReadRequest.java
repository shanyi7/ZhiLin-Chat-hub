package com.zhilin.community.pojo.message;

import lombok.Data;

/*消息已读请求*/
@Data
public class MarkReadRequest {
    private Long userId;        //消息发起者
    private Long contactId;     //消息接收者
}
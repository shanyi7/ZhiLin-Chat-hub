package com.zhilin.community.pojo.database;

import lombok.Data;

import java.time.Instant;

@Data
public class Comments {
    private Integer commentId;
    private String content;
    private Instant releaseDate;
    private Integer likes;
    private Integer replies;
    private Integer userId;
    private Integer postId;
}

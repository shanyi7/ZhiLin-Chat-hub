package com.zhilin.community.pojo.database;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

import java.time.Instant;

@Getter
@Setter
@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id", nullable = false)
    private Integer userId;

    @Column(name = "chat_number", nullable = false, length = 20)
    private String chatNumber;

    @Column(name = "password_hash", nullable = false, length = 64)
    private String passwordHash;

    @ColumnDefault("CURRENT_TIMESTAMP")
    @Column(name = "register_date")
    private Instant registerDate;

    @Column(name = "last_login")
    private Instant lastLogin;

    @ColumnDefault("inactive")
    @Lob
    @Column(name = "status")
    private String status;

    @ColumnDefault("user")
    @Lob
    @Column(name = "role")
    private String role;

    @Override
    public String toString() {
        return "User{" +
                "id=" + userId +
                ", chatNumber='" + chatNumber + '\'' +
                ", passwordHash='" + passwordHash + '\'' +
                ", registerDate=" + registerDate +
                ", lastLogin=" + lastLogin +
                ", status='" + status + '\'' +
                ", role='" + role + '\'' +
                '}';
    }
}
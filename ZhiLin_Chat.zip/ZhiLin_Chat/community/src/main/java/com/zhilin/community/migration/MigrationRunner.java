package com.zhilin.community.migration;


//import com.zhilin.community.service.UserService;
//import lombok.RequiredArgsConstructor;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Component;
//import org.springframework.transaction.annotation.Transactional;
//
//
//@Component
//@RequiredArgsConstructor
//public class MigrationRunner implements CommandLineRunner {
//    @Autowired
//    private UserService userService;
//    @Autowired
//    private PasswordEncoder passwordEncoder;
//
//    @Override
//    @Transactional
//    public void run(String... args) {
//        userService.selectAllUsers().forEach(user -> {
//            // 检测是否是明文（按你的业务特征判断）
//            if (isPlainPassword(user.getPasswordHash())) {
//                String encoded = passwordEncoder.encode(user.getPasswordHash());
//                user.setPasswordHash(encoded);
//                userService.updateUserPassword(user.getChatNumber(), encoded);
//            }
//        });
//    }
//
//    private boolean isPlainPassword(String pwd) {
//        // 根据你的业务逻辑判断，例如：
//        return pwd.length() <= 30 &&
//                !pwd.startsWith("$2a$"); // BCrypt 模式特征
//    }
//}
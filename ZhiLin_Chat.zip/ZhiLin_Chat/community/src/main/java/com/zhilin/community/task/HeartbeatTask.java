package com.zhilin.community.task;

import com.zhilin.community.websocket.SessionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class HeartbeatTask {
    @Autowired
    private SessionManager sessionManager;

    // 每30秒检测一次会话超时（45秒无活动视为失效）
    @Scheduled(fixedRate = 30_000)
    public void checkHeartbeatTimeout() {
        long now = System.currentTimeMillis();
        sessionManager.getSessions().removeIf(session ->
                (now - session.getLastActive()) > 45_000
        );
    }
}
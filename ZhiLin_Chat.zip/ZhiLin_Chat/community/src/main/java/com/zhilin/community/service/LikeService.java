package com.zhilin.community.service;

import com.zhilin.community.mapper.CommentsMapper;
import com.zhilin.community.mapper.LikesMapper;
import com.zhilin.community.mapper.PostMapper;
import com.zhilin.community.mapper.RepliesMapper;
import com.zhilin.community.pojo.response.LikeResponse;
import com.zhilin.community.pojo.database.Star;
import com.zhilin.community.pojo.database.Likes;
import com.zhilin.community.pojo.database.Notification;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
public class LikeService {
    @Autowired
    PostMapper postMapper;
    @Autowired
    CommentsMapper commentsMapper;
    @Resource
    RepliesMapper repliesMapper;
    @Resource
    LikesMapper likesMapper;
    @Autowired
    NotificationService notificationService;

    @Transactional
    public LikeResponse toggleLike(Integer userId, String targetType, Integer targetId, String action) {
        if (action.equals("like")) {
            Likes likes = new Likes(userId, targetType, targetId, Instant.now());
            likesMapper.insertLikes(likes);
            toggleLikeCount(targetType, targetId, 1);
            int likeCount = likesMapper.countLikes(targetType, targetId);
            toggleLikeNotify(targetType, targetId, userId);
            return new LikeResponse(true, likeCount);
        } else {
            likesMapper.deleteLikes(userId, targetType, targetId);
            toggleLikeCount(targetType, targetId, -1);
            toggleLikeNotify(targetType, targetId, userId);
            int likeCount = likesMapper.countLikes(targetType, targetId);
            return new LikeResponse(false, likeCount);
        }
    }

    private void toggleLikeCount(String targetType, Integer targetId, Integer delta) {
        switch (targetType) {
            case "post":
                postMapper.updateLikeCount(delta, targetId);
                break;
            case "comment":
                commentsMapper.updateLikeCount(delta, targetId);
                break;
            case "reply":
                repliesMapper.updateLikeCount(delta, targetId);
        }
    }

    private void toggleLikeNotify(String targetType, Integer targetId, Integer triggerUserId) {
        int authorId = 0;
        Notification notification = new Notification();
        authorId = switch (targetType) {
            case "post" -> postMapper.selectPostById(targetId).getUserId();
            case "comment" -> commentsMapper.getAuthorByCommentId(targetId);
            case "reply" -> repliesMapper.getAuthorByReplyId(targetId);
            default -> authorId;
        };
        notification.setUserId(authorId);
        notification.setTriggerUserId(triggerUserId);
        notification.setTargetType(targetType);
        notification.setTargetId(targetId);
        notification.setActionType("like");
        notification.setIsRead(0);
        notification.setCreateTime(Instant.now());
        notificationService.notify(notification);
    }


    public void toggleStar(Integer userId, Integer postId, String action) {
        if (action.equals("star")) {
            Star star = new Star(userId, postId, Instant.now());
            likesMapper.insertStars(star);
        } else {
            likesMapper.deleteStars(userId, postId);
        }
    }
}

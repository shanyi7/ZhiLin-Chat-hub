package com.zhilin.community.pojo.response;

import lombok.Data;

import java.time.Instant;

/*评论列表响应*/
@Data
public class CommentsResponse {
    private Integer commentId;  //评论ID
    private String content;     //评论内容
    private Instant releaseDate;    //发表日期
    private Integer likes;          //获赞数
    private Boolean liked;          //是否点赞
    private Integer replies;        //回复数

    private Integer userId;
    private String nickname;
    private String avatarUrl;
    private String briefing;
    private Long following;
    private Long followers;
    private Boolean isFollowing;
}

package com.zhilin.community.pojo.database;

import com.zhilin.community.pojo.user.Details;
import com.zhilin.community.pojo.session.NewSession;
import com.zhilin.community.pojo.user.Profile;
import com.zhilin.community.pojo.user.Stats;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

import java.time.LocalDate;

@Getter
@Setter
@Entity
@Table(name = "information")
public class Information {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "info_id", nullable = false)
    private Integer infoId;

    @Column(name = "nickname", nullable = false, length = 50)
    private String nickname;

    @ColumnDefault("/default_avatar.png")
    @Column(name = "avatar_url")
    private String avatarUrl;

    @ColumnDefault("unknown")
    @Lob
    @Column(name = "gender")
    private String gender;

    @Column(name = "briefing")
    private String briefing;

    @ColumnDefault("0")
    @Column(name = "following", columnDefinition = "int UNSIGNED")
    private Long following;

    @ColumnDefault("0")
    @Column(name = "followers", columnDefinition = "int UNSIGNED")
    private Long followers;

    @ColumnDefault("0")
    @Column(name = "points", columnDefinition = "int UNSIGNED")
    private Long points;

    @ColumnDefault("0")
    @Column(name = "likes", columnDefinition = "int UNSIGNED")
    private Long likes;

    @ColumnDefault("0")
    @Column(name = "views", columnDefinition = "int UNSIGNED")
    private Long views;

    @Column(name = "birthday")
    private LocalDate birthday;

    @Column(name = "phone_number", length = 15)
    private String phoneNumber;

    @Column(name = "wechat_id", length = 50)
    private String wechatId;

    @Column(name = "email", length = 100)
    private String email;

    @Column(name = "district", length = 50)
    private String district;

    @Column(name = "community", length = 50)
    private String community;

    @Column(name = "address", length = 100)
    private String address;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User userId;

    @Override
    public String toString() {
        return "Information{" +
                "id=" + infoId +
                ", nickname='" + nickname + '\'' +
                ", avatarUrl='" + avatarUrl + '\'' +
                ", gender='" + gender + '\'' +
                ", briefing='" + briefing + '\'' +
                ", following=" + following +
                ", followers=" + followers +
                ", points=" + points +
                ", likes=" + likes +
                ", views=" + views +
                ", birthday=" + birthday +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", wechatId='" + wechatId + '\'' +
                ", email='" + email + '\'' +
                ", district='" + district + '\'' +
                ", community='" + community + '\'' +
                ", address='" + address + '\'' +
                ", user=" + userId +
                '}';
    }

    public Profile getProfile() {
        Profile profile = new Profile();
        profile.setNickname(nickname);
        profile.setAvatarUrl(avatarUrl);
        profile.setGender(gender);
        profile.setBriefing(briefing);
        return profile;
    }

    public Stats getStats() {
        Stats stats = new Stats();
        stats.setFollowers(followers);
        stats.setFollowing(following);
        stats.setPoints(points);
        stats.setLikes(likes);
        stats.setViews(views);
        return stats;
    }

    public Details getDetails() {
        Details details = new Details();
        details.setGender(gender);
        details.setBirthday(birthday);
        details.setBriefing(briefing);
        details.setPhoneNumber(phoneNumber);
        details.setEmail(email);
        details.setDistrict(district);
        details.setCommunity(community);
        details.setAddress(address);
        return details;
    }

    public NewSession getNewSession() {
        NewSession newSession = new NewSession();
        newSession.setNickname(nickname);
        newSession.setAvatarUrl(avatarUrl);
        return newSession;
    }
}
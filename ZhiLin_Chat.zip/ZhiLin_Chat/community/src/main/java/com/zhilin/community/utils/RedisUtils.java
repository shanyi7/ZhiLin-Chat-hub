package com.zhilin.community.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.concurrent.TimeUnit;

@Component
public class RedisUtils {
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    // 基础操作
    public void set(String key, Object value, long seconds, TimeUnit timeUnit) {
        redisTemplate.opsForValue().set(key, value, seconds, TimeUnit.SECONDS);
    }

    public Object get(String key) {
        return redisTemplate.opsForValue().get(key);
    }

    // 原子递增（支持负数递减）
    public Long increment(String key, long delta) {
        return redisTemplate.opsForValue().increment(key, delta);
    }

    // 安全删除（兼容集群模式）
    public Boolean delete(String key) {
        return redisTemplate.delete(key);
    }

    // 设置过期时间（单位：秒）
    public Boolean expire(String key, long seconds) {
        return redisTemplate.expire(key, seconds, TimeUnit.SECONDS);
    }

    // 带初始值的原子递增（推荐用于计数器）
    public Long safeIncrement(String key, long delta, long initValue, long ttl) {
        if (!redisTemplate.hasKey(key)) {
            redisTemplate.opsForValue().setIfAbsent(key, initValue, ttl, TimeUnit.SECONDS);
        }
        return redisTemplate.opsForValue().increment(key, delta);
    }

    // 批量删除（支持通配符）
    public Long batchDelete(String pattern) {
        Set<String> keys = redisTemplate.keys(pattern);
        if (!keys.isEmpty()) {
            return redisTemplate.delete(keys);
        }
        return 0L;
    }

    // 获取剩余过期时间（单位：秒）
    public Long getExpire(String key) {
        return redisTemplate.getExpire(key, TimeUnit.SECONDS);
    }

    public boolean hasKey(String limitKey) {
        return false;
    }
}
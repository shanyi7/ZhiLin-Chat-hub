package com.zhilin.community.service;


import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.zhilin.community.pojo.response.PostResponse;
import com.zhilin.community.pojo.database.Post;
import com.zhilin.community.utils.AliOSSUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service
public class DynamicService {

    @Autowired
    private AliOSSUtils aliOSSUtils;

    @Autowired
    private PostService postService;

    public PageInfo<PostResponse> getAllPosts(Integer pageNum, Integer pageSize,
                                              String nickname, String content, Instant startTime, Instant endTime) {
        PageHelper.startPage(pageNum, pageSize);
        List<PostResponse> posts = postService.selectPostsList(nickname, content, startTime, endTime);
        return new PageInfo<>(posts);
    }


    // 获取关注用户的帖子
    public PageInfo<PostResponse> getFollowedPosts(Integer userId, Integer page, Integer pageSize) {
        // 1. 启动分页（自动将下一个查询分页）
        PageHelper.startPage(page, pageSize);

        // 2. 执行查询（无需手动传 offset/pageSize）
        List<PostResponse> posts = postService.selectFollowedPosts(userId);

        // 3. 用 PageInfo 包装结果（包含分页信息）
        return new PageInfo<>(posts);
    }

    //获取热门帖子列表
    public PageInfo<PostResponse> getHotPosts(Integer userId, Integer page, Integer pageSize) {
        PageHelper.startPage(page, pageSize);
        List<PostResponse> posts = postService.selectHotPosts(userId);
        return new PageInfo<>(posts);
    }

    //获取个人的所发布帖子列表
    public PageInfo<PostResponse> getSelfPosts(Integer userId, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<PostResponse> posts = postService.selectPostsListByUserId(userId);
        return new PageInfo<>(posts);
    }

    //获取个人的收藏夹帖子列表
    public PageInfo<PostResponse> getCollectionsPosts(Integer userId, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<PostResponse> posts = postService.selectCollectionsPostList(userId);
        return new PageInfo<>(posts);
    }

    public PostResponse createPost(String content, List<MultipartFile> images, Integer userId) throws IOException {
        List<String> imageUrls = new ArrayList<>();
        if (images != null && !images.isEmpty()) {
            for (MultipartFile image : images) {
                String url = aliOSSUtils.upload(image);
                imageUrls.add(url);
            }
        }

        Post post = new Post();
        post.setContent(content);
        post.setImages(imageUrls);
        post.setReleaseDate(Instant.now());
        post.setLikes(0);
        post.setComments(0);
        post.setStars(0);
        post.setUserId(userId);

        postService.createPost(post);
        int postId = postService.countPosts();
        return postService.selectPostById(postId);
    }
}

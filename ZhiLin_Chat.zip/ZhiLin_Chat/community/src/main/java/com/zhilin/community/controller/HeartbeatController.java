package com.zhilin.community.controller;

import com.zhilin.community.pojo.message.HeartbeatMessage;
import com.zhilin.community.pojo.session.SessionState;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Controller;

import java.util.concurrent.ConcurrentHashMap;

@Controller
public class HeartbeatController {
    // 使用ConcurrentHashMap维护会话状态
    private static final ConcurrentHashMap<String, SessionState> sessionMap = new ConcurrentHashMap<>();

    @MessageMapping("/heartbeat")
    public void handleHeartbeat(StompHeaderAccessor headers, @Payload HeartbeatMessage message) {
        String sessionId = headers.getSessionId();
        sessionMap.computeIfPresent(sessionId, (k, v) -> {
            v.setLastActive(System.currentTimeMillis());
            v.setDeviceInfo(message.getDeviceName());
            return v;
        });
    }
}
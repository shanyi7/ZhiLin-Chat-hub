package com.zhilin.community.pojo.reset;

import lombok.Data;

/*重置密码请求*/
@Data
public class ResetRequest {
    private String chatNumber;          //社区账号
    private String passwordHash;        //重置的新密码
}

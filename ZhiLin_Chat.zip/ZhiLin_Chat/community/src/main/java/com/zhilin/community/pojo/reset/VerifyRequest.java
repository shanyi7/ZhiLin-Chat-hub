package com.zhilin.community.pojo.reset;

import lombok.Data;

/*验证码核验请求*/
@Data
public class VerifyRequest {
    private String account;         //邮箱号或手机号，目前仅采用的是邮箱核验
    private String code;            //邮箱收发验证码
}

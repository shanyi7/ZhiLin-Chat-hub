package com.zhilin.community.controller;

import com.zhilin.community.pojo.database.ChatSession;
import com.zhilin.community.pojo.page.PageParam;
import com.zhilin.community.pojo.Result;
import com.zhilin.community.pojo.session.SessionCreateRequest;
import com.zhilin.community.service.ChatSessionService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;

@RestController
@RequestMapping("/chat/sessions")
@RequiredArgsConstructor
public class SessionController {
    private final ChatSessionService sessionService;

    // 获取用户会话列表
    @GetMapping
    public Result getSessions(
            @RequestParam Long userId,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "20") Integer pageSize) {
        return Result.success(sessionService.getUserSessions(userId, new PageParam(pageNum, pageSize)));
    }

    // 重置未读数（特殊场景使用）
    @PutMapping("/reset-unread")
    public Result resetUnread(@RequestParam String sessionId) {
        sessionService.resetUnreadCount(sessionId);
        return Result.success();
    }

    @PostMapping("/create")
    public Result create(@RequestBody SessionCreateRequest request) {
        String sessionId = request.getUserId() + "_" + request.getContactId();
        ChatSession existSession = sessionService.selectChatSession(sessionId);
        if (existSession != null) {
            return Result.success("无需创建会话已存在");
        }
        buildSession(request, sessionId, "sender");
        String receiverSessionId = request.getContactId() + "_" + request.getUserId();
        buildSession(request, receiverSessionId, "receiver");
        return Result.success(sessionId);
    }

    @GetMapping("/check")
    public Result check(@RequestParam String userId, @RequestParam String contactId) {
        String sessionId = userId + "_" + contactId;
        ChatSession existSession = sessionService.selectChatSession(sessionId);
        if (existSession == null) {
            return Result.success();
        }
        return Result.success(existSession);
    }

    private void buildSession(@RequestBody SessionCreateRequest request, String receiverSessionId, String role) {
        ChatSession receiverSession = new ChatSession();
        receiverSession.setId(receiverSessionId);
        if (role.equals("sender")) {
            receiverSession.setUserId(request.getUserId());
            receiverSession.setContactId(request.getContactId());
        } else {
            receiverSession.setUserId(request.getContactId());
            receiverSession.setContactId(request.getUserId());
        }
        receiverSession.setLastMessage("");
        receiverSession.setUnreadCount(0);
        receiverSession.setLastActiveTime(Instant.now());
        sessionService.insertChatSession(receiverSession);
    }
}
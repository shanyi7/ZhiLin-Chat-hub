package com.zhilin.community.pojo.response;

import lombok.Data;

import java.time.Instant;

/*后台管理：评论及回复统一数据响应*/
@Data
public class RemarksResponse {
    private Integer id;
    private String kind;
    private String content;
    private Instant releaseDate;
    private Integer likes;

    private Integer userId;
    private String chatNumber;
    private String nickname;

    private Integer postId;
    private Integer parentCommentId;
}

package com.zhilin.community.service;

import com.zhilin.community.exception.BusinessException;
import com.zhilin.community.utils.CodeGeneratorUtil;
import com.zhilin.community.utils.RedisUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import java.security.MessageDigest;
import java.util.concurrent.TimeUnit;

@Service
public class CaptchaService {

    private static final int MAX_ATTEMPTS = 3; // 最大尝试次数
    private static final String CAPTCHA_PREFIX = "captcha:";
    private static final String ATTEMPT_PREFIX = "attempt:";

    @Autowired
    private RedisUtils redisUtils;

    // 生成验证码（可调用工具类）
    public String generateCode() {
        return CodeGeneratorUtil.generateRandomCode(6);
    }

    // 存储验证码（业务逻辑+存储封装）
    public void storeCode(String email, String code) {
        String hashedCode = DigestUtils.md5DigestAsHex(code.getBytes());
        redisUtils.set(CAPTCHA_PREFIX + email, hashedCode, 300, TimeUnit.SECONDS);  // 5分钟过期
        redisUtils.set(ATTEMPT_PREFIX + email, "0", 300, TimeUnit.SECONDS);         // 尝试次数初始化
    }

    // 验证码核验（核心业务逻辑）
    public boolean verifyCode(String email, String inputCode) {
        // 1. 检查尝试次数
        String attemptKey = ATTEMPT_PREFIX + email;
        int attempts = Integer.parseInt(redisUtils.get(attemptKey).toString());
        if (attempts >= MAX_ATTEMPTS) {
            throw new BusinessException("ATTEMPT MAX", "验证码尝试次数已达上限，请重新获取验证码");
        }

        // 2. 获取存储的哈希值
        String captchaKey = CAPTCHA_PREFIX + email;
        String storedHash = (String) redisUtils.get(captchaKey);
        if (storedHash == null) {
            throw new BusinessException("EXPIRED", "验证码已过期");
        }

        // 3. 生成输入验证码的哈希
        String inputHash = DigestUtils.md5DigestAsHex(inputCode.getBytes());

        // 4. 安全比对（防止时序攻击）
        boolean isValid = MessageDigest.isEqual(storedHash.getBytes(), inputHash.getBytes());

        if (isValid) {
            // 5. 验证成功清除数据
            redisUtils.delete(captchaKey);
            redisUtils.delete(attemptKey);
            return true;
        } else {
            // 6. 失败时原子递增尝试次数
            redisUtils.increment(attemptKey, 1L);
            redisUtils.expire(attemptKey, 300); // 保持与验证码相同的过期时间
            return false;
        }
    }
}
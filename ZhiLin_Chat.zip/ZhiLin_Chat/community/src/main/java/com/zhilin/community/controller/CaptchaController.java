package com.zhilin.community.controller;

import com.google.code.kaptcha.impl.DefaultKaptcha;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.imageio.ImageIO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.util.concurrent.TimeUnit;

@Slf4j
@RestController
public class CaptchaController {

    @Autowired
    private DefaultKaptcha kaptcha;

    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    @GetMapping("/captcha")
    public void getCaptcha(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // 生成验证码文本
        String code = kaptcha.createText();
        // Redis 存储验证码
        String sessionId = request.getSession().getId();
        redisTemplate.opsForValue().set(
                "captcha:" + sessionId,
                code,
                3, TimeUnit.MINUTES
        );
        log.info("图形验证码已生成,code：{},对应的sessionId,sessionId：{}", code, sessionId);
        // 设置响应头禁止缓存
        response.setContentType("image/png");
        response.setHeader("Pragma", "no-cache");
        response.setHeader("Cache-Control", "no-store");

        // 生成图片响应
        try (OutputStream out = response.getOutputStream()) {
            BufferedImage image = kaptcha.createImage(code);
            ImageIO.write(image, "png", out);
        }
    }
}
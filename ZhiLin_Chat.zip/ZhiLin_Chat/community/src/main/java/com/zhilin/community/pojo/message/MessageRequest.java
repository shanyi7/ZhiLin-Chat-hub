package com.zhilin.community.pojo.message;

import lombok.Data;

import java.util.List;

/*消息发送请求*/
@Data
public class MessageRequest {
    private String tempId;      //前端依据时间戳生成的临时ID
    private MessageType messageType;
    private String content;     //消息内容
    private Integer receiverId;    //接收者用户ID
    private Integer senderId;      //发送者用户ID
    private String timestamp;   //发送即时时间
    private String status;      //消息发送状态

    public enum MessageType {
        TEXT,       // 文本消息
        IMAGE,      // 单张图片
    }
}

package com.zhilin.community.pojo.response;


import lombok.Data;

import java.time.Instant;
import java.util.List;

/*帖子列表标准响应*/
@Data
public class PostResponse {
    private Integer postId;
    private String content;
    private List<String> images;
    private Instant releaseDate;
    private Integer likes;
    private Boolean liked;
    private Integer comments;
    private Integer stars;
    private Boolean stared;
    private Instant collectionTime;

    private Integer userId;
    private String chatNumber;
    private String nickname;
    private String avatarUrl;
    private String briefing;
    private Long following;
    private Long followers;
    private Boolean isFollowing;

}

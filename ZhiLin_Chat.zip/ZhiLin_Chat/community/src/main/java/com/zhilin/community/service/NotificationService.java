package com.zhilin.community.service;


import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.zhilin.community.mapper.NotificationsMapper;
import com.zhilin.community.pojo.database.Declaration;
import com.zhilin.community.pojo.database.Notification;
import com.zhilin.community.pojo.notify.DeclareNotify;
import com.zhilin.community.pojo.notify.InteractionNotify;
import com.zhilin.community.pojo.notify.LikeNotify;
import com.zhilin.community.pojo.notify.NotifyCount;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotificationService {
    @Resource
    private NotificationsMapper notificationsMapper;

    public void notify(Notification newNotify) {
        notificationsMapper.addNotification(newNotify);
    }

    public PageInfo<InteractionNotify> getInteractionNotify(int userId, String type,
                                                            Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<InteractionNotify> notifies = notificationsMapper.selectInteractionNotifyByUserId(userId, type);
        return new PageInfo<>(notifies);
    }

    public PageInfo<LikeNotify> getLikeNotify(int userId, String type,
                                              Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<LikeNotify> notifies = notificationsMapper.selectLikeNotifyByUserId(userId, type);
        return new PageInfo<>(notifies);
    }

    public NotifyCount getUnreadCounts(int userId) {
        return notificationsMapper.selectNotifyCountByUserId(userId);
    }

    public List<DeclareNotify> getDeclareNotify(String type) {
        return notificationsMapper.selectDeclarationsByType(type);
    }

    public PageInfo<Declaration> getAllDeclarations(String title, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Declaration> declarations = notificationsMapper.selectAllDeclarations(title);
        return new PageInfo<>(declarations);
    }

    public void markNotificationsAsRead(int userId, String notifyType) {

        notificationsMapper.markNotificationsAsRead(userId, notifyType);
    }
}

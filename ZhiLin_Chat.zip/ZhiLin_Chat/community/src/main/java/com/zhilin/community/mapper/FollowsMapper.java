package com.zhilin.community.mapper;

import com.zhilin.community.pojo.follows.FollowingData;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

@Mapper
public interface FollowsMapper {

    List<FollowingData> getFollowingData(int userId);

    List<FollowingData> getFansData(int userId);

    void addFollowData(int followerId, int followedId);

    void removeFollowData(int followerId, int followedId);

    void updateFollowing(@Param("followerId") int followerId, @Param("delta") int delta);

    void updateFans(@Param("followedId") int followedId, @Param("delta") int delta);
}

package com.zhilin.community.pojo.session;


import lombok.AllArgsConstructor;
import lombok.Data;


// 会话状态记录
@Data
@AllArgsConstructor
public class SessionState {
    private String sessionId;
    private String userId;
    private String deviceInfo;
    private long lastActive;
}
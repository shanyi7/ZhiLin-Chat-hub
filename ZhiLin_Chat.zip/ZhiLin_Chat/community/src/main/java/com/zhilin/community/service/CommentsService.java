package com.zhilin.community.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.zhilin.community.mapper.CommentsMapper;
import com.zhilin.community.mapper.PostMapper;
import com.zhilin.community.pojo.response.CommentsResponse;
import com.zhilin.community.pojo.create.NewReplies;
import com.zhilin.community.pojo.response.RemarksResponse;
import com.zhilin.community.pojo.response.RepliesResponse;
import com.zhilin.community.pojo.database.Comments;
import com.zhilin.community.pojo.database.Notification;
import com.zhilin.community.pojo.database.Replies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
public class CommentsService {
    @Autowired
    PostMapper postMapper;
    @Autowired
    CommentsMapper commentsMapper;
    @Autowired
    NotificationService notificationService;

    public PageInfo<RemarksResponse> getRemarksList(Integer pageNum, Integer pageSize,
                                                    String nickname, String kind, Integer postId, String content) {
        PageHelper.startPage(pageNum, pageSize);
        List<RemarksResponse> remarks = commentsMapper.selectAllCommentsAndReplies(nickname, kind, postId, content);
        return new PageInfo<>(remarks);
    }


    public PageInfo<CommentsResponse> getCommentsList(Integer userId, Integer postId, Integer page, Integer pageSize) {
        PageHelper.startPage(page, pageSize);
        List<CommentsResponse> comments = commentsMapper.getCommentsByPostId(userId, postId);
        return new PageInfo<>(comments);
    }

    public PageInfo<RepliesResponse> getRepliesList(Integer userId, Integer commentId, Integer page, Integer pageSize) {
        PageHelper.startPage(page, pageSize);
        List<RepliesResponse> replies = commentsMapper.getRepliesByCommentId(userId, commentId);
        return new PageInfo<>(replies);
    }

    @Transactional
    public void insertComment(Integer userId, Integer postId, String content) {
        Comments comments = new Comments();
        Notification notification = new Notification();
        int authorId = postMapper.selectPostById(postId).getUserId();
        comments.setUserId(userId);
        comments.setPostId(postId);
        comments.setContent(content);
        comments.setReleaseDate(Instant.now());
        comments.setLikes(0);
        comments.setReplies(0);

        notification.setUserId(authorId);
        notification.setTriggerUserId(userId);
        notification.setTargetType("post");
        notification.setTargetId(postId);
        notification.setActionType("comment");
        notification.setContent(content);
        notification.setIsRead(0);
        notification.setCreateTime(Instant.now());

        commentsMapper.insertComment(comments);
        commentsMapper.updateCommentsCount(postId);
        notificationService.notify(notification);
    }

    @Transactional
    public void insertReplies(NewReplies reply) {
        Replies replies = new Replies();
        Notification notification = new Notification();
        int authorId = commentsMapper.getAuthorByCommentId(reply.getCommentId());
        replies.setUserId(reply.getUserId());
        replies.setPostId(reply.getPostId());
        replies.setParentCommentId(reply.getCommentId());
        replies.setContent(reply.getContent());
        replies.setReleaseDate(Instant.now());
        replies.setLikes(0);

        notification.setUserId(authorId);
        notification.setTriggerUserId(reply.getUserId());
        notification.setTargetType("comment");
        notification.setTargetId(reply.getCommentId());
        notification.setActionType("reply");
        notification.setContent(reply.getContent());
        notification.setIsRead(0);
        notification.setCreateTime(Instant.now());

        if (reply.getParentRelyId() != null) {
            replies.setParentRelyId(reply.getParentRelyId());
        }
        commentsMapper.insertReplies(replies);
        commentsMapper.updateRepliesCount(reply.getCommentId());
        commentsMapper.updateCommentsCount(reply.getPostId());
        notificationService.notify(notification);
    }
}

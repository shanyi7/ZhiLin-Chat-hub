package com.zhilin.community.pojo.database;

import lombok.Data;

import java.time.Instant;

/*收藏表*/
@Data
public class Star {
    private Integer starId;
    private Integer userId;
    private Integer postId;
    private Instant starredAt;

    public Star(Integer userId, Integer postId, Instant starredAt) {
        this.userId = userId;
        this.postId = postId;
        this.starredAt = starredAt;
    }
}

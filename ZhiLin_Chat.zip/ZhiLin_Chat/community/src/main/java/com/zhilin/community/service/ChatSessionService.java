package com.zhilin.community.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.zhilin.community.mapper.ChatSessionMapper;
import com.zhilin.community.pojo.database.ChatSession;
import com.zhilin.community.pojo.page.PageParam;
import com.zhilin.community.pojo.page.PageResult;
import lombok.RequiredArgsConstructor;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ChatSessionService {
    private final ChatSessionMapper sessionMapper;

    // 更新会话最后消息（带事务）
    @Transactional
    public void updateSession(String sessionId, String content,
                              Instant timestamp, int delta) {
        sessionMapper.updateSession(sessionId, content, timestamp, delta);
    }

    @Transactional
    public void updateSessionRead(String sessionId, int delta) {
        sessionMapper.updateSessionRead(sessionId, delta);
    }

    @Transactional
    public void insertChatSession(ChatSession chatSession) {
        sessionMapper.insertChatSession(chatSession);
    }

    @Transactional
    public ChatSession selectChatSession(@Param("sessionId") String sessionId) {
        return sessionMapper.selectChatSession(sessionId);
    }

    // 获取用户会话列表（带分页）
    public PageResult<ChatSession> getUserSessions(Long userId, PageParam param) {
        // 1. 校验分页参数
        param.validate();

        // 2. 启动分页（注意要在查询前调用）
        PageHelper.startPage(param.getPageNum(), param.getPageSize());

        // 3. 执行查询
        List<ChatSession> sessions = sessionMapper.selectUserSessions(userId);

        // 4. 封装分页结果
        return PageResult.fromPageInfo(new PageInfo<>(sessions));
    }

    // 重置未读数（原子操作）
    public void resetUnreadCount(String sessionId) {
        sessionMapper.updateSession(sessionId, null, null, 0);
    }
}
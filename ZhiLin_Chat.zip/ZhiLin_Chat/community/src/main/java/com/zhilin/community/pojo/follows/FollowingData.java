package com.zhilin.community.pojo.follows;

import lombok.Data;

@Data
public class FollowingData {
    private Integer userId;
    private String nickname;
    private String avatarUrl;
    private String briefing;
    private Long following;
    private Long followers;
    private Boolean isMutual;
    private Boolean isFollowing;

    @Override
    public String toString() {
        return "FollowingData{" +
                "userId=" + userId +
                ", nickname='" + nickname + '\'' +
                ", avatarUrl='" + avatarUrl + '\'' +
                ", briefing='" + briefing + '\'' +
                ", following=" + following +
                ", followers=" + followers +
                ", isMutual=" + isMutual +
                ", isFollowing=" + isFollowing +
                '}';
    }
}

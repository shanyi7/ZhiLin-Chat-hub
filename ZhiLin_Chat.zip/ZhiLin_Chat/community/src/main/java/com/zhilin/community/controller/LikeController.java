package com.zhilin.community.controller;

import com.zhilin.community.pojo.request.LikeRequest;
import com.zhilin.community.pojo.response.LikeResponse;
import com.zhilin.community.pojo.Result;
import com.zhilin.community.service.LikeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/like")
public class LikeController {
    @Autowired
    private LikeService likeService;

    @PostMapping("/toggle")
    public Result toggleLike(@RequestBody LikeRequest request) {
        LikeResponse response = likeService.toggleLike(request.getUserId(), request.getTargetType(),
                request.getTargetId(), request.getAction());
        return Result.success(response);
    }
}

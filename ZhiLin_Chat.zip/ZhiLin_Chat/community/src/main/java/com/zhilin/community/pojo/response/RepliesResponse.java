package com.zhilin.community.pojo.response;

import lombok.Data;

import java.time.Instant;

/*用户端：回复列表响应*/
@Data
public class RepliesResponse {
    private String replyId;
    private String content;
    private Instant releaseDate;
    private Integer likes;
    private Boolean liked;
    private String parentReplyId;

    private Integer userId;
    private String nickname;
    private String avatarUrl;
    private String briefing;
    private Long following;
    private Long followers;
}

package com.zhilin.community.pojo.notify;

import lombok.Data;

/*各通知未读消息响应*/
@Data
public class NotifyCount {
    private Integer interactionUnread;
    private Integer likeUnread;
    private Integer systemUnread;
    private Integer chatUnread;
}

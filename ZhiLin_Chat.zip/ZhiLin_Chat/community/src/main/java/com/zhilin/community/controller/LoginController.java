package com.zhilin.community.controller;

import com.zhilin.community.pojo.*;
import com.zhilin.community.pojo.login.LoginForm;
import com.zhilin.community.service.LoginService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class LoginController {
    private static final String CAPTCHA_PREFIX = "captcha:";
    @Autowired
    private LoginService loginService;
    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    @PostMapping("/login")
    public Result login(@RequestBody LoginForm form, HttpServletRequest request) {
        String sessionId = request.getSession().getId();
//        System.out.println("获取的sessionId: " + sessionId);
        String storedCode = redisTemplate.opsForValue().get(CAPTCHA_PREFIX + sessionId);
//        System.out.println(storedCode + " " + form.getCaptcha());

        if (!form.getCaptcha().equalsIgnoreCase(storedCode)) {
            return Result.error("验证码错误");
        }
        request.getSession().removeAttribute(CAPTCHA_PREFIX); // 验证后立即删除
        return loginService.validateLogin(form.getAccount(), form.getPassword());
    }

    @PostMapping("/admin")
    public Result login(@RequestBody LoginForm form) {
        return loginService.validateAdminLogin(form.getAccount(), form.getPassword());
    }
}

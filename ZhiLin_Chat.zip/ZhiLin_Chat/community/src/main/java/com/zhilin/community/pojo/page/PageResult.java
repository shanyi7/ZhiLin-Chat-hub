package com.zhilin.community.pojo.page;

import com.github.pagehelper.PageInfo;
import com.zhilin.community.pojo.database.ChatSession;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
public class PageResult<T> {
    // 响应状态码
    private Integer code;

    // 业务提示信息
    private String msg;

    // 分页数据
    private List<T> list;

    // 分页元数据
    private PageMeta meta;

    public PageResult(List<ChatSession> sessions) {
    }

    // 分页元数据内部类
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PageMeta {
        private Integer pageNum;    // 当前页
        private Integer pageSize;  // 每页数量
        private Integer pages;     // 总页数
        private Long total;         // 总记录数
        private Boolean hasPrev;    // 是否有上一页
        private Boolean hasNext;    // 是否有下一页
    }

    // 成功响应快捷方法
    public static <T> PageResult<T> ok(List<T> data, PageMeta meta) {
        return new PageResult<T>()
                .setCode(200)
                .setMsg("success")
                .setList(data)
                .setMeta(meta);
    }

    // 从PageHelper的PageInfo转换
    public static <T> PageResult<T> fromPageInfo(PageInfo<T> pageInfo) {
        PageMeta meta = new PageMeta();
        meta.setPageNum(pageInfo.getPageNum());
        meta.setPageSize(pageInfo.getPageSize());
        meta.setPages(pageInfo.getPages());
        meta.setTotal(pageInfo.getTotal());
        meta.setHasPrev(pageInfo.isHasPreviousPage());
        meta.setHasNext(pageInfo.isHasNextPage());
        return ok(pageInfo.getList(), meta);
    }
}
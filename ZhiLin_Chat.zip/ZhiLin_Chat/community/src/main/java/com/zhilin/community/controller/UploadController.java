package com.zhilin.community.controller;

import com.zhilin.community.pojo.Result;
import com.zhilin.community.service.UserService;
import com.zhilin.community.utils.AliOSSUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Map;

@Slf4j
@RestController
public class UploadController {
    @Autowired
    private AliOSSUtils aliOSSUtils;
    @Autowired
    private UserService userService;

    @PutMapping("/user/update-avatar/{chatNumber}")
    public Result updateUserAvatar(@RequestBody Map<String, String> request,
                                   @PathVariable String chatNumber) {
        String avatarUrl = request.get("avatarUrl");
        // 更新数据库中的头像Url
        boolean res = userService.updateAvatarUrl(avatarUrl, chatNumber);
        log.info("社区用户：{}；执行头像更新操作--操作结果：{}；新头像Url为：{}", chatNumber, res ? "成功" : "失败", avatarUrl);
        return res ? Result.success(avatarUrl) : Result.error("头像更新失败");
    }

    @PostMapping("/upload/image")
    public Result upload(MultipartFile image) throws IOException {
        //调用阿里云OSS工具类，将上传上来的文件存入阿里云
        String url = aliOSSUtils.upload(image);
        //将图片上传完成后的url返回，用于浏览器回显展示
        log.info("上传请求发起成功，图片Url为：{}", url);
        return Result.success(url);
    }
}

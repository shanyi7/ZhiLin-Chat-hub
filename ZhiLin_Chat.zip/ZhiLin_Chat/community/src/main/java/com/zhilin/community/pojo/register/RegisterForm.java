package com.zhilin.community.pojo.register;

import com.zhilin.community.pojo.database.Information;
import com.zhilin.community.pojo.database.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/*用户注册界面表单*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegisterForm {
    private String phoneNumber;     //手机号码
    private String email;           //邮箱
    private String password;    //注册密码

//    public User RegisterFormToUser() {          //依据注册表单转USER信息
//        User user = new User();
//        user.setPasswordHash(passwordHash);
//        return user;
//    }

//    public Information RegisterFormToInformation() {        //依据注册表单信息转Information信息
//        Information information = new Information();
//        information.setPhoneNumber(phoneNumber);
//        information.setEmail(email);
//        return information;
//    }
}

package com.zhilin.community.pojo.notify;

import lombok.Data;

import java.time.Instant;
import java.util.List;

/*点赞消息通知*/
@Data
public class LikeNotify {
    private Integer notificationId;
    private Integer userId;
    private Integer triggerUserId;
    private String nickname;
    private String avatarUrl;
    private String targetType;
    private Integer targetId;
    private String actionType;
    private String content;
    private String sourceContent;
    private Integer isRead;
    private Instant createTime;
    private List<String> images;
}

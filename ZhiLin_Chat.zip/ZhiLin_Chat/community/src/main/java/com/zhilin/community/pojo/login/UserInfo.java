package com.zhilin.community.pojo.login;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*前端界面所需共享用户信息*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserInfo {
    private Integer userId;         //用户ID
    private String chatNumber;      //社区账号
    private String avatarUrl;       //头像url
}

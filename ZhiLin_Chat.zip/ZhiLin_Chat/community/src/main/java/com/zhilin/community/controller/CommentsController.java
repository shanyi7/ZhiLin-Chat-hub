package com.zhilin.community.controller;

import com.github.pagehelper.PageInfo;
import com.zhilin.community.pojo.create.NewReplies;
import com.zhilin.community.pojo.response.RemarksResponse;
import com.zhilin.community.pojo.response.RepliesResponse;
import com.zhilin.community.pojo.Result;
import com.zhilin.community.service.CommentsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/comments")
public class CommentsController {
    @Autowired
    private CommentsService commentsService;


    @GetMapping("/all")
    public Result getAllRemarks(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String nickname,
            @RequestParam(required = false) String kind,
            @RequestParam(required = false) Integer postId,
            @RequestParam(required = false) String content
    ) {
        PageInfo<RemarksResponse> pageInfo = commentsService.getRemarksList(pageNum, pageSize, nickname, kind, postId, content);
        return Result.success(pageInfo);
    }


    @GetMapping("/replies")
    public Result getReplies(@RequestParam Integer userId,
                             @RequestParam Integer commentId,
                             @RequestParam(defaultValue = "1") Integer page,
                             @RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<RepliesResponse> pageInfo = commentsService.getRepliesList(userId, commentId, page, pageSize);
        return Result.success(pageInfo);
    }

    @PostMapping("/send-replies")
    public Result addRelies(@RequestBody NewReplies reply) {
        commentsService.insertReplies(reply);
        return Result.success();
    }
}

package com.zhilin.community.service;

import com.zhilin.community.pojo.database.Information;
import com.zhilin.community.pojo.reset.ResetRequest;
import com.zhilin.community.pojo.user.UpdateForm;
import com.zhilin.community.pojo.database.User;

import java.time.Instant;
import java.util.List;

public interface UserService {
    /**
     * 用户登录
     *
     * @param chatNumber,passwordHash 社区账号
     * @return 返回查询结果
     */
    User checkUserByChatNumber(String chatNumber, String passwordHash);

    /**
     * 用户登录
     *
     * @param phoneNumber,passwordHash 手机号
     * @return 返回查询结果
     */
    User checkUserByPhoneNumber(String phoneNumber, String passwordHash);

    /**
     * 用户登录
     *
     * @param email,passwordHash 邮箱号
     * @return 返回查询结果
     */
    User checkUserByEmail(String email, String passwordHash);

    User findUserByChatNumber(String chatNumber);

    User findUserByPhoneNumber(String phoneNumber);

    User findUserByEmail(String email);
    /**
     * 注册用户
     *
     * @param user user对象
     */
    void registerUserInfo(User user);

    /**
     * 注册相关个人信息
     *
     * @param information information对象
     */
    void registerRelateInfo(Information information);

    /**
     * 核验邮箱
     *
     * @param email 邮箱账号
     * @return 返回查询结果
     */
    Boolean checkEmail(String email);


    /**
     * 核验邮箱
     *
     * @param phoneNumber 手机号
     * @return 返回查询结果
     */
    boolean checkPhoneExists(String phoneNumber);

    /**
     * 获取用户信息
     *
     * @param chatNumber 社区账号
     * @return 返回查询结果
     */
    User getUserByChatNumber(String chatNumber);

    /**
     * 获取用户信息
     *
     * @param userId 用户ID
     * @return 返回查询结果
     */
    User getUserByID(int userId);

    /**
     * 获取关联信息
     *
     * @param chatNumber 社区账号
     * @return 返回查询结果
     */
    public Information getInformationByChatNumber(String chatNumber);

    /**
     * 更新用户密码
     *
     * @param resetRequest 社区账号
     * @return 返回结果
     */
    boolean updatePassword(ResetRequest resetRequest);

    /**
     * 获取用户信息
     *
     * @param userId 用户表ID
     * @return 返回查询结果
     */
    Information getInformationByUserId(int userId);

    /**
     * 获取最近的用户ID
     *
     * @return 返回查询结果
     */
    int getLatestID();

    /**
     * 更新用户密码
     *
     * @param avatarUrl,chatNumber 头像路径,社区账号
     * @return 返回结果
     */
    boolean updateAvatarUrl(String avatarUrl, String chatNumber);

    /**
     * 更新关联信息
     *
     * @param updateForm 用户关联信息
     * @return 返回结果
     */
    boolean updateInfo(UpdateForm updateForm);


    /**
     * 获取用户社区账号
     *
     * @param email 邮箱号
     * @return 返回查询结果
     */
    String getChatNumberByEmail(String email);


    /**
     * 更新邮箱号
     *
     * @param email,chatNumber 邮箱号，社区账号
     * @return 返回结果
     */
    boolean updateEmail(String email, String chatNumber);


    /**
     * 更新最后登录时间
     *
     * @param chatNumber,lastLogin 社区账号,最后登录时间
     */
    void updateLastLogin(Instant lastLogin, String chatNumber);

    List<User> selectAllUsers();

    void updateUserPassword(String chatNumber, String passwordHash);

    List<User> selectAccountList(String chatNumber, String status, Instant startTime, Instant endTime);

    void updateAccountStatus(Integer userId, String status);

    void deleteAccountById(Integer userId);

    User checkAdminByChatNumber(String chatNumber);
}

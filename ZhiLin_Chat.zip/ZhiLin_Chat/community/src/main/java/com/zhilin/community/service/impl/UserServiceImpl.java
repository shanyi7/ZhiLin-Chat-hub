package com.zhilin.community.service.impl;

import com.zhilin.community.mapper.UserMapper;
import com.zhilin.community.pojo.database.Information;
import com.zhilin.community.pojo.reset.ResetRequest;
import com.zhilin.community.pojo.user.UpdateForm;
import com.zhilin.community.pojo.database.User;
import com.zhilin.community.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Qualifier("userMapper")
    @Autowired
    private UserMapper userMapper;

    @Override
    public User checkUserByChatNumber(String chatNumber, String passwordHash) {
        return userMapper.checkUserByChatNumber(chatNumber, passwordHash);
    }

    @Override
    public User checkUserByPhoneNumber(String phoneNumber, String passwordHash) {
        return userMapper.checkUserByPhoneNumber(phoneNumber, passwordHash);
    }

    @Override
    public User checkUserByEmail(String email, String passwordHash) {
        return userMapper.checkUserByEmail(email, passwordHash);
    }

    @Override
    public User findUserByChatNumber(String chatNumber) {
        return userMapper.findUserByChatNumber(chatNumber);
    }

    @Override
    public User findUserByPhoneNumber(String phoneNumber) {
        return userMapper.findUserByPhoneNumber(phoneNumber);
    }

    @Override
    public User findUserByEmail(String email) {
        return userMapper.findUserByEmail(email);
    }

    @Override
    public void registerUserInfo(User user) {
        userMapper.addUserInfo(user);
    }

    @Override
    public void registerRelateInfo(Information information) {
        userMapper.addRelateInfo(information);
    }

    @Override
    public Boolean checkEmail(String email) {
        return userMapper.checkEmailExists(email);
    }

    @Override
    public boolean checkPhoneExists(String phoneNumber) {
        return userMapper.checkPhoneNumberExists(phoneNumber);
    }

    @Override
    public User getUserByChatNumber(String chatNumber) {
        return userMapper.getUserByChatNumber(chatNumber);
    }

    @Override
    public User getUserByID(int userId) {
        return userMapper.getUserByID(userId);
    }

    @Override
    public Information getInformationByChatNumber(String chatNumber) {
        return userMapper.getInformationByChatNumber(chatNumber);
    }

    @Override
    public boolean updatePassword(ResetRequest resetRequest) {
        return userMapper.updatePassword(resetRequest);
    }

    @Override
    public Information getInformationByUserId(int userId) {
        return userMapper.getInformationByUserId(userId);
    }

    @Override
    public int getLatestID() {
        return userMapper.getLatestID();
    }

    @Override
    public boolean updateAvatarUrl(String avatarUrl, String chatNumber) {
        return userMapper.updateAvatarUrl(avatarUrl, chatNumber);
    }

    @Override
    public boolean updateInfo(UpdateForm updateForm) {
        return userMapper.updateInfo(updateForm);
    }

    @Override
    public String getChatNumberByEmail(String email) {
        return userMapper.getChatNumberByEmail(email);
    }

    @Override
    public boolean updateEmail(String email, String chatNumber) {
        return userMapper.updateEmail(email, chatNumber);
    }

    @Override
    public void updateLastLogin(Instant lastLogin, String chatNumber) {
        userMapper.updateLastLogin(lastLogin, chatNumber);
    }

    @Override
    public List<User> selectAllUsers() {
        return userMapper.selectAllUsers();
    }

    @Override
    public void updateUserPassword(String chatNumber, String passwordHash) {
        userMapper.updateUserPassword(chatNumber, passwordHash);
    }

    @Override
    public List<User> selectAccountList(String chatNumber, String status, Instant startTime, Instant endTime) {
        return userMapper.selectAccountList(chatNumber, status, startTime, endTime);
    }

    @Override
    public void updateAccountStatus(Integer userId, String status) {
        userMapper.updateAccountStatus(userId, status);
    }

    @Override
    public void deleteAccountById(Integer userId) {
        userMapper.deleteAccountById(userId);
    }

    @Override
    public User checkAdminByChatNumber(String chatNumber) {
        return userMapper.checkAdminByChatNumber(chatNumber);
    }
}

package com.zhilin.community.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.jdbc.SQL;

import java.time.LocalDateTime;
import java.util.Map;

// 动态SQL构造器
public class MessageSqlBuilder {
    public static String buildMessageQuery(
            @Param("userId") Long userId,
            @Param("contactId") Long contactId,
            @Param("startTime") LocalDateTime startTime) {

        return new SQL() {{
            SELECT("*");
            FROM("chat_message");
            WHERE("(sender_id = #{userId} AND receiver_id = #{contactId})")
                    .OR().WHERE("(sender_id = #{contactId} AND receiver_id = #{userId})");
            if (startTime != null) {
                WHERE("timestamp >= #{startTime}");
            }
            ORDER_BY("timestamp DESC");
        }}.toString();
    }
}

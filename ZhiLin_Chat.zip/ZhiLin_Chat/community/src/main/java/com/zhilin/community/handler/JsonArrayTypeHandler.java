package com.zhilin.community.handler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class JsonArrayTypeHandler extends BaseTypeHandler<List<String>> {
    private static final Logger log = LoggerFactory.getLogger(JsonArrayTypeHandler.class);
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final TypeReference<List<String>> LIST_TYPE = new TypeReference<>() {
    };

    @Override
    public void setNonNullParameter(PreparedStatement ps, int i,
                                    List<String> parameter, JdbcType jdbcType) throws SQLException {
        try {
            ps.setString(i, objectMapper.writeValueAsString(parameter));
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize image list", e);
            throw new SQLException("Image list serialization failed", e);
        }
    }

    @Override
    public List<String> getNullableResult(ResultSet rs, String columnName) throws SQLException {
        return parseJsonArray(rs.getString(columnName));
    }

    @Override
    public List<String> getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
        return parseJsonArray(rs.getString(columnIndex));
    }

    @Override
    public List<String> getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
        return parseJsonArray(cs.getString(columnIndex));
    }

    private List<String> parseJsonArray(String json) {
        if (json == null || json.isEmpty()) {
            return Collections.emptyList();
        }

        try {
            // 处理阿里云OSS格式的URL数组
            return objectMapper.readValue(json, LIST_TYPE);
        } catch (JsonProcessingException e) {
            log.warn("Invalid JSON array format: {}", json, e);
            return tryFallbackParse(json);
        }
    }

    private List<String> tryFallbackParse(String json) {
        // 处理不带引号的旧数据格式（兼容性处理）
        try {
            String cleaned = json.replaceAll("^\\[|]$", "")
                    .replaceAll("\"", "");
            if (cleaned.isEmpty()) return Collections.emptyList();

            return Arrays.asList(cleaned.split("\\s*,\\s*"));
        } catch (Exception ex) {
            log.error("Fallback parsing failed for: {}", json, ex);
            return Collections.emptyList();
        }
    }
}
package com.zhilin.community.pojo.session;

import lombok.Data;

/*新会话创建请求*/
@Data
public class SessionCreateRequest {
    private Integer userId;            //发起者用户ID
    private Integer contactId;         //接收者对象用户ID
}

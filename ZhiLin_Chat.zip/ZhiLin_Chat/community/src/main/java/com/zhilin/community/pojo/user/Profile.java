package com.zhilin.community.pojo.user;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*用户个人信息卡片显示部分*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Profile {
    private String nickname;        //昵称
    private String avatarUrl;       //头像URL
    private String gender;          //性别
    private String briefing;        //简介
}
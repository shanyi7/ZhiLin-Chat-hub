package com.zhilin.community.pojo.request;

import lombok.Data;

/*通知消息标记已读操作请求*/
@Data
public class MarkNotifyReadRequest {
    private Integer userId;
    private String notifyType;
}

package com.zhilin.community.pojo.user;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/*详细介绍部分*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Details {
    private String gender;          //性别
    private String briefing;        //简介
    private String phoneNumber;     //电话号码
    private String email;           //邮箱号
    private String district;        //所属地区
    private LocalDate birthday;     //生日
    private String community;       //隶属社区
    private String address;         //详细地址
}

package com.zhilin.community.service;

import com.zhilin.community.pojo.*;
import com.zhilin.community.pojo.database.Information;
import com.zhilin.community.pojo.database.User;
import com.zhilin.community.pojo.login.LoginResponse;
import com.zhilin.community.pojo.login.UserInfo;
import com.zhilin.community.utils.JwtUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
public class LoginService {
    @Autowired
    private UserService userService;
    @Autowired
    private PasswordEncoder passwordEncoder;

    public Result validateLogin(String account, String rawPassword) { // 参数为原始密码
        User loginUser = findUserByIdentifier(account);

        if (loginUser != null && validateCredentials(rawPassword, loginUser.getPasswordHash())) {
            return buildUserSuccessResponse(loginUser);
        }

        log.warn("普通用户登录失败 - 账号: {}", account);
        return Result.error("账号或密码错误");
    }

    public Result validateAdminLogin(String account, String rawPassword) { // 参数为原始密码
        User loginUser = userService.checkAdminByChatNumber(account);

        if (loginUser != null && validateCredentials(rawPassword, loginUser.getPasswordHash())) {
            return buildAdminSuccessResponse(loginUser);
        }

        log.warn("管理员登录失败 - 账号: {}", account);
        return Result.error("账号或密码错误");
    }

//    public Result validateLogin(String account, String password) {
//        User loginUser;
//        if (isEmail(account)) {
//            loginUser = userService.checkUserByEmail(account, password);
//        } else if (isPhone(account)) {
//            loginUser = userService.checkUserByPhoneNumber(account, password);
//        } else {
//            loginUser = userService.checkUserByChatNumber(account, password);
//        }
//        if (loginUser != null) {
//            Map<String, Object> claims = new HashMap<>();
//            claims.put("id", loginUser.getUserId());
//            claims.put("chat_number", loginUser.getChatNumber());
//            claims.put("register_date", loginUser.getRegisterDate().toString());
//            //使用JWT工具类，生成身份令牌
//            String token = JwtUtils.generateJwt(claims);
//            log.info("登录操作,本地时间：{},用户账号为：{} 登录成功", LocalDateTime.now(), loginUser.getChatNumber());
//            userService.updateLastLogin(Instant.now(), account);
//            Information loginUserInfo = userService.getInformationByUserId(loginUser.getUserId());
//            UserInfo userInfo = new UserInfo(loginUser.getUserId(), loginUser.getChatNumber(), loginUserInfo.getAvatarUrl());
//            LoginResponse loginResponse = new LoginResponse(token, userInfo);
//            return Result.success(loginResponse);
//        }
//        return Result.error("账号或密码错误");
//    }

    private User findUserByIdentifier(String account) {
        try {
            if (isEmail(account)) {
                return userService.findUserByEmail(account);
            } else if (isPhone(account)) {
                return userService.findUserByPhoneNumber(account);
            } else {
                return userService.findUserByChatNumber(account);
            }
        } catch (Exception e) {
            log.debug("用户查找失败 - 账号: {}", account);
            return null;
        }
    }

    private boolean validateCredentials(String rawPassword, String encodedPassword) {
        // 安全验证密码（自动处理salt和哈希次数）
//        System.out.println(rawPassword + "," + encodedPassword);
//        System.out.println(passwordEncoder.matches(rawPassword, encodedPassword));
        return passwordEncoder.matches(rawPassword, encodedPassword);
    }

    private Result buildUserSuccessResponse(User user) {
        Map<String, Object> claims = buildJwtClaims(user);
        String token = JwtUtils.generateJwt(claims);

        log.info("用户登录成功 - ID: {} | 聊天号: {}", user.getUserId(), user.getChatNumber());
        updateLoginInfo(user.getChatNumber());

        return Result.success(new LoginResponse(token, buildUserInfo(user)));
    }

    private Result buildAdminSuccessResponse(User user) {
        Map<String, Object> claims = buildJwtClaims(user);
        String token = JwtUtils.generateJwt(claims);

        log.info("管理员登录成功 - ID: {} | 账号号: {}", user.getUserId(), user.getChatNumber());


        return Result.success(new LoginResponse(token, buildUserInfo(user)));
    }

    private Map<String, Object> buildJwtClaims(User user) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("id", user.getUserId());
        claims.put("chat_number", user.getChatNumber());
        claims.put("register_date", user.getRegisterDate().toString());
        return claims;
    }

    private void updateLoginInfo(String account) {
        try {
            userService.updateLastLogin(Instant.now(), account);
        } catch (DataAccessException e) {
            log.error("更新登录时间失败 - 账号: {}", account, e);
        }
    }

    private UserInfo buildUserInfo(User user) {
        Information info = userService.getInformationByUserId(user.getUserId());
        return new UserInfo(
                user.getUserId(),
                user.getChatNumber(),
                info != null ? info.getAvatarUrl() : "default-avatar.png"
        );
    }

    private boolean isEmail(String input) {
        return input.matches("^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$");
    }

    private boolean isPhone(String input) {
        return input.matches("^1[3-9]\\d{9}$");
    }
}

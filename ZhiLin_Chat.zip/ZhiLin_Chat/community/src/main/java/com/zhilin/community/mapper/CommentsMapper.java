package com.zhilin.community.mapper;

import com.zhilin.community.pojo.response.CommentsResponse;
import com.zhilin.community.pojo.response.RemarksResponse;
import com.zhilin.community.pojo.response.RepliesResponse;
import com.zhilin.community.pojo.database.Comments;
import com.zhilin.community.pojo.database.Replies;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;


import java.util.List;

@Mapper
public interface CommentsMapper {
    @Select("SELECT comments.*,info.nickname,info.avatar_url,info.following,info.followers," +
            "EXISTS (SELECT true FROM userfollows WHERE follower_id = #{userId} AND followed_id = comments.user_id) " +
            "AS isFollowing," +
            "IF(likes.user_id IS NOT NULL, 'true', 'false') AS liked " +
            "FROM comments " +
            "INNER JOIN information info ON comments.user_id = info.user_id " +
            "LEFT JOIN likes ON " +
            "likes.target_id = comment_id " +
            "AND likes.target_type = 'comment' " +
            "AND likes.user_id = #{userId} " +
            "WHERE comments.post_id = #{postId} " +
            "ORDER BY release_date DESC")
    List<CommentsResponse> getCommentsByPostId(Integer userId, Integer postId);


    @Select("SELECT replies.*,info.nickname,info.avatar_url,info.following,info.followers, " +
            "EXISTS (SELECT true FROM userfollows WHERE follower_id = #{userId} AND followed_id = replies.user_id) " +
            "AS isFollowing," +
            "IF(likes.user_id IS NOT NULL, 'true', 'false') AS liked " +
            "FROM replies " +
            "INNER JOIN information info ON replies.user_id = info.user_id " +
            "LEFT JOIN likes ON " +
            "likes.target_id = reply_id " +
            "AND likes.target_type = 'reply' " +
            "AND likes.user_id = #{userId} " +
            "WHERE replies.parent_comment_id = #{commentId} " +
            "ORDER BY release_date DESC")
    List<RepliesResponse> getRepliesByCommentId(Integer userId, Integer commentId);


    @Insert("INSERT INTO comments(comment_id,content,release_date,likes,replies,user_id,post_id) " +
            "VALUES(#{commentId},#{content},#{releaseDate},#{likes},#{replies},#{userId},#{postId})")
    void insertComment(Comments comments);

    @Insert("INSERT INTO replies(reply_id,content,release_date,likes,user_id,post_id,parent_comment_id,parent_reply_id) " +
            "VALUES(#{replyId},#{content},#{releaseDate},#{likes},#{userId},#{postId},#{parentCommentId},#{parentRelyId})")
    void insertReplies(Replies replies);


    @Select("SELECT comments.user_id FROM comments WHERE comment_id = #{commentId}")
    int getAuthorByCommentId(Integer commentId);

    @Update("UPDATE posts SET comments = comments + 1 WHERE post_id = #{postId}")
    void updateCommentsCount(Integer postId);

    @Update("UPDATE comments SET replies = replies + 1 WHERE comment_id = #{commentId}")
    void updateRepliesCount(Integer commentId);

    @Update("UPDATE comments SET likes = GREATEST(0, likes + #{delta}) WHERE comment_id = #{commentId}")
    void updateLikeCount(Integer delta, Integer commentId);


    List<RemarksResponse> selectAllCommentsAndReplies(String nickname, String kind, Integer postId, String content);
}

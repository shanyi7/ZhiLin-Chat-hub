package com.zhilin.community.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.zhilin.community.mapper.UserMapper;
import com.zhilin.community.pojo.database.Information;
import jakarta.annotation.Resource;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InformationService {

    @Resource
    UserMapper userMapper;

    public PageInfo<Information> getUsersInfo(Integer pageNum, Integer pageSize,
                                              String nickname, String gender, String community) {
        PageHelper.startPage(pageNum, pageSize);
        List<Information> users = userMapper.selectAllInformation(nickname, gender, community);
        return new PageInfo<>(users);
    }
}

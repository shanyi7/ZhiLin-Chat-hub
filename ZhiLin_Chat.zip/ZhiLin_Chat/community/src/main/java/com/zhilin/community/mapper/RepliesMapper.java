package com.zhilin.community.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface RepliesMapper {

    @Update("UPDATE replies SET likes = GREATEST(0, likes + #{delta}) WHERE reply_id = #{replyId}")
    void updateLikeCount(Integer delta, Integer replyId);

    @Select("SELECT replies.user_id FROM replies WHERE reply_id = #{replyId}")
    Integer getAuthorByReplyId(Integer replyId);
}

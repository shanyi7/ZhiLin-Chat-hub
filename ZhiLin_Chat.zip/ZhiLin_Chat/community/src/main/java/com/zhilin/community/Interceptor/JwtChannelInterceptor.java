package com.zhilin.community.Interceptor;

public class JwtChannelInterceptor {
}

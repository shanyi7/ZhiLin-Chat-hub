package com.zhilin.community.controller;

import com.zhilin.community.pojo.message.MarkReadRequest;
import com.zhilin.community.pojo.Result;
import com.zhilin.community.service.ChatMessageService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/chat/messages")
@RequiredArgsConstructor
public class MessageController {
    @Autowired
    private final ChatMessageService messageService;
//    @Autowired // Spring Boot自动配置的Bean
//    private SimpMessagingTemplate messagingTemplate;

    // 发送消息（整合WebSocket推送）
//    @PostMapping
//    public Result sendMessage(@RequestBody ChatMessage message) {
//        messageService.sendMessage(message);
//        // WebSocket推送逻辑（需注入SimpMessagingTemplate）
//        messagingTemplate.convertAndSendToUser(
//                message.getReceiverId().toString(),
//                "/queue/messages",
//                message
//        );
//        return Result.success();
//    }

    // 获取聊天记录
    @GetMapping("/history")
    public Result getHistory(
            @RequestParam Long userId,
            @RequestParam Long contactId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime beforeTime,
            @RequestParam(defaultValue = "10") int size) {

        return Result.success(messageService.getMessageHistory(userId, contactId, beforeTime, size));
    }

    // 标记已读
    @PostMapping("/markRead")
    public Result markAsRead(@RequestBody MarkReadRequest request) {
        messageService.batchMarkRead(request.getUserId(), request.getContactId());
        return Result.success();
    }


}
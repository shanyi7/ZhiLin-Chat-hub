package com.zhilin.community.pojo.database;

import lombok.Data;

import java.time.Instant;

@Data
public class Likes {
    private Integer likeId;
    private Integer userId;
    private String targetType;  //点赞对象类型：帖子（post）、评论（comment）、回复（reply）
    private Integer targetId;   //目标Id
    private Instant createTime;

    public Likes(Integer userId, String targetType, Integer targetId, Instant createTime) {
        this.userId = userId;
        this.targetType = targetType;
        this.targetId = targetId;
        this.createTime = createTime;
    }
}

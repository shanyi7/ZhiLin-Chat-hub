package com.zhilin.community.service;

import com.zhilin.community.pojo.follows.FollowingData;

import java.util.List;

public interface FollowService {
    /**
     * 获取用户的关注列表信息
     *
     * @param userId 用户ID
     * @return 返回查询结果
     */
    List<FollowingData> getFollowingData(int userId);

    /**
     * 获取用户的粉丝列表信息
     *
     * @param userId 用户ID
     * @return 返回查询结果
     */
    List<FollowingData> getFansData(int userId);


    /**
     * 添加关注关系数据
     *
     * @param followerId,followedId 关注者及被关注者的ID
     */
    void addFollowData(int followerId, int followedId);

    /**
     * 删除关注关系数据
     *
     * @param followerId,followedId 关注者及被关注者的ID
     */
    void removeFollowData(int followerId, int followedId);

    /**
     * 更新用户的关注数
     *
     * @param followerId,delta 关注者ID,更新数量：1/ -1
     */
    void updateFollowing(int followerId, int delta);

    /**
     * 更新用户的粉丝数
     *
     * @param followedId,delta 被关注者ID,更新数量：1/ -1
     */
    void updateFans(int followedId, int delta);
}

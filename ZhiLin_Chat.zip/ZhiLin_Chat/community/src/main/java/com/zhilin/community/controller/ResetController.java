package com.zhilin.community.controller;

import com.zhilin.community.pojo.reset.ResetRequest;
import com.zhilin.community.pojo.Result;
import com.zhilin.community.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ResetController {
    @Autowired
    private UserService userService;

    @PostMapping("/reset-password")
    public Result resetPassword(@RequestBody ResetRequest resetRequest) {
        boolean res = userService.updatePassword(resetRequest);
        return res ? Result.success("重置密码成功") : Result.error("网络异常错误");
    }
}

package com.zhilin.community.pojo.message;


import lombok.Data;

/*心跳消息实体*/
@Data
public class HeartbeatMessage {
    private String deviceName;
    private String agentVersion;
    private Long timestamp;
}
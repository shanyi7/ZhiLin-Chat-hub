package com.zhilin.community.pojo.create;


import lombok.Data;

/*添加新评论请求*/
@Data
public class NewComments {
    private Integer userId;
    private Integer postId;
    private String content;
}

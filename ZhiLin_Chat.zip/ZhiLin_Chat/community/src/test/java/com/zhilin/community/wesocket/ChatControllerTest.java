package com.zhilin.community.wesocket;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zhilin.community.controller.ChatController;
import com.zhilin.community.pojo.database.ChatMessage;
import com.zhilin.community.pojo.message.MessageRequest;
import com.zhilin.community.service.ChatMessageService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.messaging.simp.SimpMessagingTemplate;

import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class ChatControllerTest {

    @Mock
    private ChatMessageService chatService;

    @Mock
    private SimpMessagingTemplate messagingTemplate;

    @Spy
    private ObjectMapper objectMapper = new ObjectMapper();

    @InjectMocks
    private ChatController chatController;

    @Test
    void handleMessage_SendsAckAndMessage() throws JsonProcessingException {
        // 构造请求
        MessageRequest request = new MessageRequest();
        request.setSenderId(123L);
        request.setReceiverId(456L);
        request.setTempId("temp-789");
        request.setContent("Hello");
        request.setTimestamp(Instant.now().toString());

        // 调用处理逻辑
        chatController.handleMessage(request);

        // 验证 chatService.sendMessage 是否调用
        verify(chatService).sendMessage(any(ChatMessage.class));

        // 验证第一次调用（发送 ACK 给发送方）
        verify(messagingTemplate).convertAndSendToUser(
                eq("123"),
                eq("/queue/ack"),
                any(String.class) // ACK 是 JSON 字符串
        );

        // 验证第二次调用（发送消息给接收方）
        verify(messagingTemplate).convertAndSendToUser(
                eq("456"),
                eq("/queue/messages"),
                any(ChatMessage.class) // 消息是 ChatMessage 对象
        );
    }
}